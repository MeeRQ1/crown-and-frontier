"""Build documentation, tokens, integration aids, manifest, and component catalog.
Run after build_vectors.py and after copying approved landmark PNGs into landmarks/.
"""
from pathlib import Path
from collections import Counter
import hashlib, json, html
from PIL import Image
from fontTools.ttLib import TTFont

R=Path(__file__).resolve().parents[1]
def write(path,text):
 p=R/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n')
palette={
 'ivory':'#eee7d7','ivory-raised':'#f5efe2','ivory-inset':'#e0d9c7',
 'slate':'#384342','slate-raised':'#465150','slate-inset':'#303b3b',
 'ink':'#253332','muted-on-ivory':'#59645d','muted-on-slate':'#c2c6b7',
 'line-on-ivory':'#93988a','line-on-slate':'#78867c',
 'brass':'#c2ab72','brass-ink':'#665322','sea':'#a9c5ca',
 'danger-on-ivory':'#9c3b33','danger-on-slate':'#efada0',
 'positive-on-ivory':'#406448','positive-on-slate':'#b4c7a1',
 'warning-on-ivory':'#70531f','warning-on-slate':'#e6c786',
 'route':'#365c70','neutral-land':'#ded8c2',
}
factions=['#bfaaa0','#acb8a0','#a3b8c1','#c8bc8c','#b8aac0','#a1beb5','#c7b0a2','#afbac9','#c0c29e','#c9b09f','#b2b4cd','#bdd0c0']
tokens={'version':'1.1.0','direction':'Ivory War Atlas / Slate Command Room','colors':palette,'factionFills':factions,
 'type':{'headings':{'family':'Barlow Condensed','weight':600},'body':{'family':'Source Sans 3','weight':400},'numbers':{'family':'Source Sans 3','weight':600,'features':['tnum','lnum']},'sizesPx':{'body':16,'denseTable':14,'caption':13,'section':23,'screen':30,'worldLabel':19}},
 'spacingPx':[4,8,12,16,24,32],'radiiPx':{'panel':0,'control':2,'pill':'Only for map point badges'},
 'strokesPx':{'uiIcon':1.7,'hairline':1,'controlBoundary':1,'focusRing':2},
 'displayPx':{'icon':24,'denseIcon':20,'touchHitTarget':44,'resource':48,'flag':[30,20],'counter':[96,64],'landmark':[64,128]},
 'mapZoom':{'world':'Borders, realm names, priority capital markers; no rich landmarks','regional':'Province names after collision checks, simple markers, restrained terrain','local':'Illustrated landmarks only where readable and non-overlapping'},
 'motionMs':{'hover':90,'panel':140},'textureOpacity':{'ivory':0.25,'slate':0.15,'sea':0.3},
 'budgets':{'initialRasterBytes':0,'oneVisibleLandmarkDecodeMax':4,'lazyLoadLandmarkArt':True,'svgRasterCachePerStyleAndDpr':True}}
write('design/tokens.json',json.dumps(tokens,indent=2))
css='\n'.join(f'  --cf-{k}: {v};' for k,v in palette.items())
write('styles/tokens.css',f''':root {{
{css}
  --cf-body: "Source Sans 3", "Segoe UI", sans-serif;
  --cf-heading: "Barlow Condensed", "Arial Narrow", sans-serif;
  --cf-space-1: 4px; --cf-space-2: 8px; --cf-space-3: 12px;
  --cf-space-4: 16px; --cf-space-6: 24px; --cf-space-8: 32px;
}}
@font-face {{ font-family:"Barlow Condensed"; src:url("../fonts/BarlowCondensed-Medium.woff2") format("woff2"),url("../fonts/BarlowCondensed-Medium.ttf") format("truetype");font-weight:500;font-style:normal;font-display:swap; }}
@font-face {{ font-family:"Barlow Condensed"; src:url("../fonts/BarlowCondensed-SemiBold.woff2") format("woff2"),url("../fonts/BarlowCondensed-SemiBold.ttf") format("truetype");font-weight:600;font-style:normal;font-display:swap; }}
@font-face {{ font-family:"Source Sans 3"; src:url("../fonts/SourceSans3-Variable.woff2") format("woff2"),url("../fonts/SourceSans3-Variable.ttf") format("truetype");font-weight:200 900;font-style:normal;font-display:swap; }}''')
write('styles/components.css','''/* Scoped reference primitives, not a replacement for the game's stylesheet. */
.cf-panel {background:var(--cf-slate);color:var(--cf-ivory);border:1px solid var(--cf-line-on-slate);border-radius:0;padding:16px;}
.cf-register {background:var(--cf-ivory);color:var(--cf-ink);padding:12px;border:1px solid var(--cf-line-on-ivory);}
.cf-title {font:600 23px/1.05 var(--cf-heading);letter-spacing:.06em;text-transform:uppercase;margin:0 0 12px;}
.cf-body {font:400 16px/1.4 var(--cf-body);}
.cf-number {font-variant-numeric:tabular-nums lining-nums;font-weight:600;}
.cf-command {border:1px solid var(--cf-line-on-slate);border-radius:2px;background:var(--cf-slate-raised);color:var(--cf-ivory);font:600 16px/1.2 var(--cf-body);min-height:44px;padding:8px 16px;cursor:pointer;}
.cf-command:hover {background:var(--cf-slate-inset);}
.cf-command[aria-pressed="true"],.cf-command-primary {background:var(--cf-brass);color:var(--cf-ink);border-color:var(--cf-brass-ink);}
.cf-command:focus-visible {outline:2px solid var(--cf-ivory);outline-offset:3px;box-shadow:0 0 0 5px var(--cf-ink);}
.cf-command:disabled {opacity:.6;cursor:default;border-style:dashed;}
.cf-icon {display:inline-block;width:24px;height:24px;flex:0 0 24px;vertical-align:middle;}
.cf-mask {background:currentColor;mask-repeat:no-repeat;mask-position:center;mask-size:contain;}
.cf-table {border-collapse:collapse;width:100%;font:400 16px/1.3 var(--cf-body);}
.cf-table th {text-align:left;font-weight:600;padding:8px;border-bottom:1px solid var(--cf-line-on-slate);}
.cf-table td {padding:8px;border-bottom:1px solid var(--cf-line-on-slate);}
.cf-table .cf-numeric {text-align:right;font-variant-numeric:tabular-nums lining-nums;}
.cf-positive {color:var(--cf-positive-on-slate);}
.cf-danger {color:var(--cf-danger-on-slate);}
.cf-register .cf-positive {color:var(--cf-positive-on-ivory);}
.cf-register .cf-danger {color:var(--cf-danger-on-ivory);}
.cf-counter {position:relative;width:96px;height:64px;color:var(--cf-ink);font:600 14px/1 var(--cf-body);font-variant-numeric:tabular-nums;}
.cf-counter>img.cf-counter-frame {position:absolute;inset:0;width:100%;height:100%;}
.cf-counter-flag {position:absolute;left:3px;top:3px;width:20px;height:14px;object-fit:contain;}
.cf-counter-symbol {position:absolute;left:41px;top:6px;width:24px;height:24px;}
.cf-counter-strength {position:absolute;left:28px;right:4px;top:30px;text-align:center;white-space:nowrap;}
.cf-counter-bars {position:absolute;left:4px;right:4px;top:51px;display:flex;gap:4px;}
.cf-counter-bar {height:7px;flex:1;background:var(--cf-ivory-inset);border:1px solid var(--cf-ink);}
.cf-counter-bar>span {display:block;height:100%;background:var(--cf-positive-on-ivory);}
@media (prefers-reduced-motion:reduce) {.cf-command{transition:none;}}
''')
write('integration/asset-url.ts',r'''/** Supply the actual deployment base from your build tool. No root-path assumption. */
export function assetUrl(deploymentBase: string, relativePath: string): string {
  if (/^(?:[a-z]+:|\/)/i.test(relativePath) || relativePath.split('/').includes('..')) {
    throw new Error('Asset path must be a relative pack path');
  }
  return `${deploymentBase.replace(/\/?$/, '/') }assets/crown-frontier-atlas/${relativePath}`;
}
// Vite example only, after copying pack to public/assets/crown-frontier-atlas/:
// const coal = assetUrl(import.meta.env.BASE_URL, 'resources/coal.svg');
// For monochrome SVGs, inline trusted bundled SVG or set CSS mask-image to this URL.
// External <img> does not inherit parent currentColor. Use it for multicolor assets.
''')
write('README.md','''# Crown & Frontier — Ivory War Atlas asset pack

Individual assets for the approved **light ivory atlas / warm slate command room** direction. This is a modular production starting point, not a baked game screen and not an implemented game update.

## Start here

1. Unzip the folder and open `index.html` to inspect the asset catalog and small component examples.
2. Give Claude this folder, your main update prompt, and `CLAUDE_ASSET_RULES.md`.
3. Claude should inspect the current repository, map each asset to existing features, then integrate and verify the full update in one working branch.

Copy the runtime files you actually use into the repository. Keep documentation, construction sources, license notices, and the manifest with the project; the whole gallery need not ship to players. Paths in the catalog are relative and work after unzipping.

## Contents

- `icons/`: navigation, resources, military, map, and editor symbols; editable 24 px SVGs.
- `resources/`: larger vector commodity illustrations, including existing nitrates.
- `menu-emblems/`: ten optional editable section motifs for the full menu overhaul.
- `design/screen-redesign.md`: screen-specific compositions, screenshot observations and coverage acceptance rules.
- `counters/`: empty frames, branch symbols and status overlays. Values remain live.
- `flags/` and `insignia/`: twelve generic fictional identities. No automatic faction assignment.
- `terrain/`, `markers/`, `decorations/`, `textures/`: atlas components with separate low-detail forms.
- `landmarks/`: four separate transparent engraved raster illustrations.
- `fonts/` and `licenses/`: self-hosted Barlow Condensed and Source Sans 3 with their OFL notices.
- `design/`, `styles/`, `integration/`: tokens, scoped component CSS, path helper and technical rules.
- `manifest.json`: per-asset paths, sizes, origins and SHA-256 hashes.
- `sources/`: vector authoring scripts and image-generation prompts.
- `QA_REPORT.md`: what was actually checked, plus integration checks still required.

The approved look is expressed through clear geometry and purposeful hierarchy. Texture and ornament are secondary. No royal serif headings, glass panels, oversized rounded cards, decorative dashboard statistics or baked interface lettering.
''')
write('CLAUDE_ASSET_RULES.md','''# Implementation rules for Claude

Use this pack with the main Crown & Frontier update prompt. Read `README.md`, `design/tokens.json`, `ASSET_SPEC.md`, `PROVENANCE.md`, and the manifest before integration. The current game repository is the authority for implemented mechanics and faction identity; this pack has not inspected that code.

## 1. Deliver one coherent update

Work through audit, integration, refinement and verification in one implementation pass on an isolated branch. Internal checkpoints are required; do not turn every checkpoint into a request for approval. Finish a reviewable pull request with screenshots, validation and known limitations. Do not merge or deploy unless the user has authorized it.

This pack does not authorize additional game systems. Deepen and polish what already exists. The requested new map content remains a huge Earth map, a large Europe map and a large fictional map, plus refinement of the existing map-making tools. Inspect the repository to establish what is actually present before writing the plan.

## 2. Art direction is the first priority

Build an ivory strategic atlas inside warm slate command furniture. Use the palette and font families supplied. Keep the map dominant. Use brass for a focused selection or primary action, brick red for danger, sage for favourable values, and blue-grey for water and routes. Brass should not decorate every divider.

The map should feel like an authored geographical document: coherent coastlines, restrained engraved landforms, fine borders, sensible roads, legible labels, muted political washes. Geometry, shorelines, ownership, occupation, routes and text are generated from live map data. Do not substitute a huge painting for the playable world.

Treat the reference as direction, not a literal tracing. Solve the real game's content density. Panel shapes, spacing and breakpoints may change when necessary for readable controls. Keep a record of meaningful deviations and their purpose.

## 3. Use assets by role

- Small icons are monochrome `currentColor` SVGs. Inline trusted bundled SVGs or use CSS masks. An external SVG `<img>` cannot inherit its parent's color. Multicolor flags and illustrations may use normal `<img>` or cached canvas images.
- Preserve SVG viewBoxes and optical margins. Do not normalize every asset to the same cropped bounds. Show resources at roughly 40–56 px; UI symbols at 20–24 px; keep a 44 px hit area for touch controls.
- Counter chrome is intentionally empty. Add faction flag, branch symbol, strength and real status bars as live layers. Do not bake numbers or nation names into images. A status shape must retain a text explanation or tooltip.
- The fictional flags are optional identity ingredients, not historical flags and not a mandate to rename or recolor existing realms. Explicitly map them only where suitable. Real-world scenarios require accurate era-appropriate identity choices, separate from this generic flag set.
- Rich landmark PNGs are visual location markers, not interface icons. Use the simple vector marker at distant zoom. A port or factory illustration must correspond to a real location in the simulation. Suppress overlapping artwork.
- Terrain motifs are sparse accents. Orient ridges along real geography, distribute forests deterministically, and vary scale modestly. Avoid evenly stamped rows of the same symbol. Never obscure borders, movement routes or labels.
- No new navy, air-force, resource or research feature is implied by a symbol being available. Do not invent mechanics to justify unused art.

## 4. Typography and hierarchy

Use **Barlow Condensed 600** for short titles and command headings. Use **Source Sans 3** for body copy, tables, tooltips and values. Use tabular lining numerals and right-align comparable quantities. No artificial condensation, outlined letters, blanket all-caps body copy, tiny condensed tables, or gratuitous letter spacing.

Aim for 16 px normal text and at least 14 px in dense tables. Render map labels at a readable screen-pixel size rather than letting world scaling shrink them indefinitely. Move, shorten or suppress lower-priority labels before allowing collisions. Separate place names from realm names in size, weight and placement, not elaborate effects.

## 5. Interface craft

Follow `design/screen-redesign.md` for every existing menu and dialog, including surfaces discovered in the audit. Give each task a suitable composition; leave no old generic panel shell untouched. Menu motifs are optional header punctuation, not a replacement for redesigned information architecture.

Build a clear status rail, a dominant map, task-oriented inspector panels, and compact contextual commands. Use squared panels, thin rules, aligned rows and occasional ivory inset registers. Selectors and controls must feel related across trade, diplomacy, army and research views. Use existing meaningful data; do not add empty dashboard blocks for visual balance.

Communicate real consequences before commitment: cost, time, dependencies, likely benefit, confidence and uncertainty where the game models them. Give rejected actions an actionable reason. Trade should make the player's shortage, commitment, partner offer and delivery outcome understandable. Connect economic constraints, military readiness and research choices to the systems already implemented; do not claim depth that the simulation lacks.

Disabled, selected, focused, hovered, loading and empty states need deliberate treatment. Use label/icon/shape redundancy so color is never the only signal. Preserve keyboard navigation and a visible focus ring. Touch must support the same tasks without hover-only details or accidental map movement.

## 6. Texture restraint and map scales

Texture belongs behind content, never in type or chart lines. The supplied tiles have subtle marks; blend them over a flat token color at the suggested opacity. Do not apply multiple full-strength grain layers. Avoid CSS filters and live noise on every province.

At world view, show realm identity and essential geography. At regional view, introduce collision-checked province labels and simple landmarks. At local view, reveal richer artwork where it is useful. Base transitions on projected screen size and measured readability. Fixed zoom values must be fitted to the current renderer.

For Earth and Europe, use consistent source geography, projection and adjacency. Document data provenance and licenses. The editor must export structured playable maps, validate graph connectivity and scenario data, and report specific problems. Do not call a decorative map import a working custom-map editor.

## 7. Performance and technical integration

Serve locally bundled fonts and assets with correct GitHub Pages base paths. Keep the static browser build usable without a mandatory external service. Lazy-load landmark art after first paint; use mip levels or reduced derivatives only when profiling shows a benefit. Cache rasterized SVGs by size, style and device pixel ratio. Never decode or rasterize them per frame.

Only draw visible provinces, labels and markers. Profile the huge Earth scenario as well as small campaigns. Measure frame work, simulation ticks, memory, startup and save/load on declared hardware. Use workers or architectural changes when measurements justify them, not by reflex. Preserve save compatibility or provide a documented migration and backup route.

## 8. Acceptance before handoff

Verify the current project's build, type checks and meaningful tests. Play through trade shortages, war orders, diplomacy, research decisions, map editing and save reload wherever those features exist. Test the long labels, empty states and disabled actions that tidy demo screenshots miss.

Inspect actual desktop and narrow touch layouts at multiple zoom tiers and browser scales. Check keyboard focus, contrast, asset errors, label collisions, ownership readability and all deployment subpaths. Include component states and real game screenshots in the pull request. Explain what was not tested. Automated checks alone do not establish that the art direction works in play.

Do not describe the update as complete while supplied assets remain merely copied into a folder. The player must encounter the coherent direction throughout setup, map, inspectors, commands and feedback. Improve rough pieces against the same rules rather than falling back to generic cards or introducing another unrelated visual style.
''')
write('ASSET_SPEC.md','''# Asset specification

Menu extension v1.1 adds ten 96 × 96 monochrome motifs, eight 24 × 24 UI icons and one 96 × 88 nitrates illustration. The motifs are suitable for sparse 40–72 px use in screen identities; preserve a text label. See `design/screen-redesign.md`.

All paths are relative to the pack root. `manifest.json` lists exact files and hashes. SVG source is the editable master. Raster master PNGs are delivered unmodified from generation; transparent margins and style require inspection at final display scale.

| Family | Master size | Intended use |
| --- | --- | --- |
| UI icons | 24 × 24 viewBox | 20–24 px, 1.7-unit stroke, inline or masked |
| Resource art | 96 × 88 | 40–56 px in commodity registers |
| Fictional flags | 96 × 64 | 3:2 ratio, 30 × 20 px or larger; full-color |
| Insignia | 48 × 48 | Monochrome charges for identity composition |
| Standard counter frame | 96 × 64 | Native screen pixels; expand layout for long values |
| Compact counter frame | 56 × 36 | Summary only; one small identity and branch symbol |
| Tactical symbols/status | 24 × 24 | 12–24 px, live labels explain branch/status |
| Terrain motifs | 96 × 72 | Sparse, cached, no interactive meaning by themselves |
| Map point markers | 24 × 24 | Low-detail substitutes for rich landmarks |
| Surface tiles | 256 × 256 | Repeat over a flat matching base color; no heavy filters |
| Hatch/stipple | 16 × 16 | Occupation/fog overlay, pair with legend |
| Sea lines | 32 × 32 | Optional sparse sea texture; remove if routes compete |
| Rich landmarks | See manifest | 64–128 px at local zoom; lazy-loaded |

## Counter slots

Coordinates are in the standard frame's viewBox. Chrome is not a functional widget.

| Slot | x, y | width × height | Rule |
| --- | --- | --- | --- |
| Identity flag | 3, 3 | 20 × 14 | Preserve 3:2 flag aspect; center vertically |
| Branch symbol | 41, 6 | 24 × 24 | Dark mono symbol, plain background |
| Strength text | 28, 30 | 64 × 14 | Center; localizable compact format plus exact tooltip |
| Readiness bars | 4, 51 | 88 × 7 | Two bars separated by 4 px; actual metric mapping disclosed |
| Optional status | Outside right edge | 16 × 16 | Expand hit area and collision box; never hide another counter |

Compact frame: identity region x=2–17, summary region x=20–52; branch at 26,6 with 20 × 20 footprint. Omit bars and numeric text at this scale. Use a tooltip/inspector for details. Fit counts from the real simulation; no illustrative values in production.

Use `styles/components.css` as a reference, adapting to the repository's framework. It is intentionally scoped and does not globally reset the application. Numbers, bars and flag assignments in the catalog are labelled sample component content.

## Tokens and contrast

Token colors are separated for text on ivory and on slate. Never place dark positive/danger text on slate or light positive/danger text on ivory. `QA_REPORT.md` records measured normal-text contrast for the intended pairs. Thin decorative rules and pastel faction fills are not text colors or sufficient interaction boundaries by themselves. Use darker outlines for controls and shape/label redundancy for military states.

## Display limits

Use the generated landmark transparency bounds to align the visible object, not merely the center of the full PNG canvas. Large empty margins are retained in the master; make appropriately sized exports in the implementation branch if needed. Use vector point markers until an illustration has enough visible pixels to read. These raster masters are not certified to be pixel-perfect isometric sprites or mutually aligned animation frames.

Surface textures place no features across the outer tile boundary except the deliberately periodic sea lines/hatch. They tile without cut fragments; repeated grain is still a repeated pattern, so apply lightly. Contours, roads, shorelines, coast hatching and border strokes should be generated from geometry in the renderer, not assembled from this pack's decoration.
''')
write('PROVENANCE.md','''# Provenance and distribution notes

## Newly constructed parts

The SVG assets, vector construction script, tokens, gallery and implementation documents were created for this Crown & Frontier request. They do not embed third-party icon collections or extracted game artwork. They may be adapted as project assets. This pack is not an assertion of exclusive copyright or a new license for the existing game repository.

## Generated landmark artwork

`landmarks/*.png` are AI-generated illustrations created with OpenAI image generation on 2026-10-06, using the user's approved mockup for visual direction. They are not hand-drawn artwork. Exact prompts are in `sources/landmark-prompts.json`. Raster originals are preserved without postprocessing. Similarity and rendering consistency should be evaluated in the running game; these four illustrations do not imply exclusive visual ownership or historical accuracy.

## Fonts

Barlow Condensed: Copyright 2017 The Barlow Project Authors. Source: https://github.com/google/fonts/tree/main/ofl/barlowcondensed

Source Sans 3: Adobe; copyright and Reserved Font Name notices are in the supplied license. Source: https://github.com/google/fonts/tree/main/ofl/sourcesans3

Font binaries were downloaded from the official Google Fonts repository on 2026-10-06. Complete upstream TTF files and OFL 1.1 notices are retained. WOFF2 files are lossless format conversions of those binaries, without subsetting or renaming. Keep the corresponding OFL files with redistributed fonts. Font licenses do not require placing your game code under the OFL.

## Map geography and faction identities

No third-party geographic dataset, real-world map image, official coat of arms, soundtrack or licensed game asset is bundled. Flags are generic fictional designs named for their geometric charge; verify their fit before assigning them to existing factions. The requested Earth/Europe geography must be obtained and attributed separately during implementation.
''')

entries=[]
for p in sorted(R.rglob('*')):
 if p.is_file() and p.suffix in ('.svg','.png','.ttf','.woff2'):
  rel=p.relative_to(R).as_posix(); group=rel.split('/')[0]
  item={'id':rel.replace('/','.') if group=='fonts' else rel.rsplit('.',1)[0].replace('/','.'),'path':rel,'group':group,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
    'origin':'ai-generated-raster' if group=='landmarks' else 'third-party-font' if group=='fonts' else 'original-vector-construction'}
  if p.suffix=='.svg':
   import xml.etree.ElementTree as ET
   el=ET.parse(p).getroot();item.update(viewBox=el.attrib['viewBox'],monochrome='currentColor' in p.read_text())
  elif p.suffix=='.png':
   im=Image.open(p);item.update(width=im.width,height=im.height,mode=im.mode,alphaBoundingBox=list(im.getchannel('A').getbbox()) if 'A' in im.getbands() else None)
  else:
   f=TTFont(p);item['fontFamily']=f['name'].getDebugName(1);item['fontStyle']=f['name'].getDebugName(2);f.close()
  entries.append(item)
write('manifest.json',json.dumps({'pack':'crown-frontier-ivory-war-atlas','version':'1.1.0','generatedOn':'2026-10-06','assetCount':len(entries),'assets':entries},indent=2))

# Browsable part catalog: no map screenshot, game screen or flattened interface.
sections=[]
for group in ['icons','menu-emblems','resources','counters','markers','flags','insignia','terrain','textures','decorations','landmarks']:
 cards=[]
 for e in entries:
  if e['group']!=group:continue
  label=e['path'].split('/')[-1].rsplit('.',1)[0]
  if e.get('monochrome'):
   art=(R/e['path']).read_text().replace('<svg ','<svg aria-hidden="true" ')
  else:art=f'<img loading="lazy" src="{e["path"]}" alt="{html.escape(label)}"/>'
  cards.append(f'<a class="asset {group}" href="{e["path"]}" title="Open editable asset">{art}<span>{html.escape(label)}</span><small>{e["path"]}</small></a>')
 sections.append(f'<section id="{group}"><h2>{group.upper()}</h2><div class="grid">'+''.join(cards)+'</div></section>')
swatches=''.join(f'<div class="swatch"><i style="background:{v}"></i><span>{k}</span><code>{v}</code></div>' for k,v in palette.items())
write('index.html','''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Crown & Frontier · Asset catalog</title><link rel="stylesheet" href="styles/tokens.css"><link rel="stylesheet" href="styles/components.css"><style>
*{box-sizing:border-box}body{margin:0;background:var(--cf-ivory);color:var(--cf-ink);font:400 16px/1.4 var(--cf-body)}header{padding:32px 5vw;background:var(--cf-slate);color:var(--cf-ivory);border-bottom:4px solid var(--cf-brass)}h1{font:600 38px/1 var(--cf-heading);letter-spacing:.06em;margin:0 0 12px}header p{max-width:760px;margin:8px 0;color:var(--cf-muted-on-slate)}nav{display:flex;flex-wrap:wrap;gap:16px;margin-top:20px}nav a{color:var(--cf-ivory);text-decoration:underline;text-underline-offset:4px}main{max-width:1440px;margin:auto;padding:32px 5vw}section{margin-bottom:40px}h2{font:600 26px/1 var(--cf-heading);letter-spacing:.04em;margin:0 0 16px;padding-bottom:8px;border-bottom:1px solid var(--cf-line-on-ivory)}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(135px,1fr));gap:12px}.asset{display:flex;flex-direction:column;justify-content:flex-start;align-items:center;gap:8px;color:var(--cf-ink);text-decoration:none;border:1px solid #a7a99b;background:var(--cf-ivory-raised);padding:14px 8px;min-height:128px}.asset:hover{outline:2px solid var(--cf-brass-ink)}.asset svg,.asset img{display:block;width:64px;height:60px;object-fit:contain;flex-shrink:0}.asset.icons svg,.asset.markers svg{width:24px;height:24px;margin:12px 0}.asset small{font-size:11px;overflow-wrap:anywhere;text-align:center;color:var(--cf-muted-on-ivory)}.asset span{font-size:14px;text-align:center}.textures img{width:90px;height:90px}.landmarks{background-color:#e7e5da;background-image:linear-gradient(45deg,#dadbd3 25%,transparent 25%),linear-gradient(-45deg,#dadbd3 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#dadbd3 75%),linear-gradient(-45deg,transparent 75%,#dadbd3 75%);background-size:20px 20px;background-position:0 0,0 10px,10px -10px,-10px 0}.landmarks img{width:140px;max-width:100%;height:140px}.swatches{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}.swatch{display:grid;grid-template-columns:32px 1fr;gap:4px 8px;font-size:13px}.swatch i{grid-row:span 2;width:32px;height:36px;border:1px solid #7c8579}.swatch code{font-size:11px}.examples{display:grid;grid-template-columns:1fr 1fr;gap:16px}.counter-examples{display:flex;align-items:center;gap:24px;flex-wrap:wrap;margin-top:16px}.type-demo{font-size:18px}.type-demo strong{font:600 30px var(--cf-heading)}a:focus-visible{outline:3px solid var(--cf-brass-ink);outline-offset:3px}@media(max-width:700px){.examples{grid-template-columns:1fr}h1{font-size:30px}}
</style><header><h1>CROWN &amp; FRONTIER</h1><p>Ivory War Atlas · Slate Command Room · Modular asset catalog v1.1</p><p>Individual editable parts. The small examples below demonstrate assembly; sample quantities do not describe the game's simulation.</p><nav>'''+''.join(f'<a href="#{g}">{g.title()}</a>' for g in ['icons','menu-emblems','resources','counters','flags','terrain','textures','landmarks'])+'''<a href="CLAUDE_ASSET_RULES.md">Claude rules</a></nav></header><main><section><h2>PALETTE &amp; TYPE</h2><div class="swatches">'''+swatches+'''</div><p class="type-demo"><strong>TRADE &amp; INDUSTRIAL CAPACITY</strong><br>Clear contracts, costs and consequences. <span class="cf-number">12,480 · −24 / month · 8.2k</span></p></section>
<section><h2>SMALL COMPONENT EXAMPLES — SAMPLE DATA</h2><div class="examples"><div class="cf-panel"><h3 class="cf-title">Command states</h3><button class="cf-command">Inspect</button> <button class="cf-command cf-command-primary">Negotiate</button> <button class="cf-command" disabled>Unavailable</button><p>Keyboard focus uses a double contrast ring. Touch targets remain 44 px tall.</p><div class="cf-register">Coal balance <span class="cf-number cf-danger">−12 / month</span><br>Projected reserve: <span class="cf-number">4 months</span></div></div><div class="cf-panel"><h3 class="cf-title">Register &amp; counter</h3><table class="cf-table"><tr><th>Material</th><th class="cf-numeric">Monthly balance</th></tr><tr><td>Coal</td><td class="cf-numeric cf-danger">−12</td></tr><tr><td>Iron</td><td class="cf-numeric cf-positive">+8</td></tr></table><div class="counter-examples"><div class="cf-counter" role="img" aria-label="Sample selected infantry: 8,200 strength; two sample readiness bars"><img class="cf-counter-frame" src="counters/frames/selected.svg" alt=""><img class="cf-counter-flag" src="flags/fictional-sun.svg" alt=""><span class="cf-icon cf-mask cf-counter-symbol" style="mask-image:url('counters/symbols/infantry.svg')"></span><span class="cf-counter-strength">8.2k</span><span class="cf-counter-bars"><span class="cf-counter-bar"><span style="width:80%"></span></span><span class="cf-counter-bar"><span style="width:60%"></span></span></span></div><p>Flag, symbol, values and bars<br>remain separate live layers.</p></div></div></div></section>
'''+''.join(sections)+'''<footer><p>See CLAUDE_ASSET_RULES.md and ASSET_SPEC.md before integration. Fonts and raster artwork have separate provenance notices. This catalog is not a playable game build.</p></footer></main></html>''')
print('Catalog and manifest:',len(entries),'assets;',dict(Counter(e['group'] for e in entries)))
