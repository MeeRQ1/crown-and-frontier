"""Menu extension: original vectors for existing screen identities. Stdlib only.
Run after build_vectors.py and before build_pack.py. No live UI text is baked in.
"""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def write(path,body,size=24,stroke=1.7):
 p=R/path;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><g fill="none" stroke="currentColor" stroke-width="{stroke}" stroke-linecap="round" stroke-linejoin="round">{body}</g></svg>\n')
icons={
 'realm':'<path d="M3 7l5 4 4-7 4 7 5-4-3 13H6L3 7zm3 9h12"/>',
 'victory':'<path d="M7 3h10v7a5 5 0 0 1-10 0V3zm0 2H3v4q0 4 5 4m9-8h4v4q0 4-5 4M12 15v5m-5 2h10"/>',
 'chronicle':'<path d="M5 3h13v17H7q-4 0-4-3V6q0-3 2-3zm0 14h13M8 7h7M8 11h7M8 3v14"/>',
 'envoy':'<path d="M12 21V3m0 0h9l-3 4 3 4h-9M3 21h18M4 6l3 3-3 3m-2-3h5"/>',
 'guarantee':'<path d="M4 4l8-2 8 2v8q0 6-8 10-8-4-8-10V4zm4 6h8m-4-4v11"/>',
 'budget':'<path d="M4 2h16v20H4zM8 6h8m-8 4h3m-3 4h3m-3 4h3m3-8h2m-2 4h2m-2 4h2"/>',
 'notification':'<path d="M4 17h16l-2-3V9a6 6 0 0 0-12 0v5l-2 3zm6 3q2 3 4 0M12 1v2"/>',
 'nitrates':'<path d="M3 17l5-6 4 2 5-7 5 11-6 4H8l-5-4zm5-6v10m4-8 4 8m1-15-1 15M3 17h19"/>',
}
for n,b in icons.items():write(f'icons/{n}.svg',b)

# Screen motifs are optional header punctuation, not badges for every row or node.
emblems={
 'realm-budget':'<path d="M19 25h43v47H19zM25 25v47M32 34h22m-22 9h12m-12 9h12m-12 9h12"/><path d="M49 14h29l-4 12H53zM49 14l7 4 7-9 8 9 7-4"/><ellipse cx="68" cy="60" rx="13" ry="5"/><path d="M55 60v16c0 7 26 7 26 0V60m-26 8c0 7 26 7 26 0"/>',
 'industry-trade':'<path d="M9 63V41l15-9v10l16-10v13h17v18H9zm36-18V18h8v27M16 52h5m9 0h5m9 0h5"/><path d="M64 35h21l-6-6m6 6-6 6M85 54H64l6-6m-6 6 6 6M15 74h65"/><path d="M19 77v4m7-4v4m7-4v4m7-4v4m7-4v4m7-4v4m7-4v4m7-4v4" stroke-width=".9"/>',
 'military':'<path d="M16 19h64v52H16zM24 27l48 36M72 27L24 63M16 45h64"/><path d="M32 81h32M48 71v10"/><path d="M10 13h8m60 0h8M10 77h8m60 0h8"/>',
 'research':'<path d="M31 13h34m-27 0v30L20 73q-4 8 6 8h44q10 0 6-8L58 43V13M30 58h36"/><path d="M41 22v22l-8 14" stroke-width="1"/><circle cx="48" cy="67" r="4"/><circle cx="60" cy="73" r="2"/><path d="M73 25l7-7m-3 18h10M22 28l-8-5"/>',
 'national-focus':'<path d="M38 10h20v19H38zM40 18l4 4 10-8"/><path d="M48 29v13H22v12m26-12h26v12M48 42v26"/><path d="M13 54h18v18H13zM65 54h18v18H65zM39 68h18v18H39zM22 60v6m-3-3h6M69 60l10 6m0-6-10 6"/>',
 'diplomacy':'<path d="M15 20h27v24H15zM54 20h27v24H54zM15 20l13 13 14-13m12 0 13 13 14-13"/><path d="M18 60l15-9 14 8 10-5 22 12-10 16-12 4-25-16-9-2-5-8zm27-1-7 10 8 3 9-8 16 12M43 71l17 11"/>',
 'wars-peace':'<path d="M15 22l54 54M23 14l54 54M19 18l-6 13M27 10l-8 8m50 58 10 10m-3-17 10 10M77 18L23 72M69 10L15 64m54-54 8 8m-4 8 10 4M23 72l-9 9m4-13-9 9"/><path d="M39 46l9-5 9 5v15l-9 7-9-7z" fill="#eee7d7"/>',
 'victory':'<path d="M32 14h32v26q0 19-16 19T32 40V14zm0 9H17v15q0 16 18 16m29-31h15v15q0 16-18 16M48 59v15M32 81h32M39 74h18v7"/><path d="M12 69l8-5-4-9m-4 14 2-10m70 10-8-5 4-9m4 14-2-10"/>',
 'chronicle':'<path d="M16 17h48v64H25q-12 0-12-8V27q0-10 3-10zm9 0v64M13 70h51M34 30h21m-21 9h21m-21 9h13"/><circle cx="70" cy="60" r="17" fill="#eee7d7"/><path d="M70 49v11l9 5M58 60h2m20 0h2M70 73v-2"/>',
 'help':'<path d="M9 23q20-7 39 3 19-10 39-3v50q-20-7-39 3-19-10-39-3V23zm39 3v50M18 34h15m-15 10h15m-15 10h10"/><path d="M60 39a6 6 0 0 1 12 0c0 7-6 7-6 15m0 7v1"/>',
}
# Cut out underlying strokes instead of painting ivory patches: both themes stay readable.
emblems['chronicle']='<defs><mask id="cf-menu-clock-cut" maskUnits="userSpaceOnUse" x="0" y="0" width="96" height="96"><rect width="96" height="96" fill="white" stroke="none"/><circle cx="70" cy="60" r="19" fill="black" stroke="none"/></mask></defs><g mask="url(#cf-menu-clock-cut)"><path d="M16 17h48v64H25q-12 0-12-8V27q0-10 3-10zm9 0v64M13 70h51M34 30h21m-21 9h21m-21 9h13"/></g><circle cx="70" cy="60" r="17"/><path d="M70 49v11l9 5M58 60h2m20 0h2M70 73v-2"/>'
emblems['wars-peace']='<defs><mask id="cf-menu-shield-cut" maskUnits="userSpaceOnUse" x="0" y="0" width="96" height="96"><rect width="96" height="96" fill="white" stroke="none"/><path d="M37 45l11-6 11 6v17l-11 8-11-8z" fill="black" stroke="none"/></mask></defs><g mask="url(#cf-menu-shield-cut)"><path d="M15 22l54 54M23 14l54 54M19 18l-6 13M27 10l-8 8m50 58 10 10m-3-17 10 10M77 18L23 72M69 10L15 64m54-54 8 8m-4 8 10 4M23 72l-9 9m4-13-9 9"/></g><path d="M39 46l9-5 9 5v15l-9 7-9-7z"/>'
for n,b in emblems.items():write(f'menu-emblems/{n}.svg',b,96,1.8)

p=R/'resources/nitrates.svg'
p.write_text('''<svg xmlns="http://www.w3.org/2000/svg" width="96" height="88" viewBox="0 0 96 88"><path d="M15 67l10-24 15 3 12-24 20 12 10 33-22 9H31z" fill="#c9d0bd" stroke="#596b65" stroke-width="2"/><path d="M25 43l6 33m9-30 20 30M52 22l8 54m12-42L60 76M15 67l25-7 20 2 22 5M40 46v14" fill="none" stroke="#879486" stroke-width="1.6"/><path d="M52 22l-12 24 20 16 12-28z" fill="#e5e7d9" opacity=".6"/></svg>\n''')
print('Added 19 editable menu/resource assets')
