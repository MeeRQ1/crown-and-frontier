"""Original vector construction source. Run from any directory; writes into this pack.
Does not overwrite raster art, fonts, or documentation. Python standard library only.
"""
from pathlib import Path
from html import escape
import math, random

ROOT = Path(__file__).resolve().parents[1]
INK='#303b3b'; PAPER='#eee7d7'; LINE='#8b897c'; BRASS='#b49a5a'

def svg(path, body, w=24, h=24, mono=False):
    p=ROOT/path; p.parent.mkdir(parents=True,exist_ok=True)
    attrs='fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"' if mono else ''
    p.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><g {attrs}>{body}</g></svg>\n')

ICONS={
 'atlas':'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18M5 6.5h14M5 17.5h14"/>',
 'politics':'<path d="M3 9l9-6 9 6H3zm2 11h14M7 10v7m5-7v7m5-7v7M3 21h18"/>',
 'economy':'<ellipse cx="9" cy="6" rx="6" ry="2.5"/><path d="M3 6v8c0 3 12 3 12 0V6M3 10c0 3 12 3 12 0M3 14c0 3 12 3 12 0"/><path d="M18 9v11m-3-3 3 3 3-3"/>',
 'trade':'<path d="M3 7h17l-4-4m4 4-4 4M21 17H4l4-4m-4 4 4 4"/>',
 'diplomacy':'<path d="M2 8l4-3 5 3 3-1 8 5-4 7-4 1-7-5-3-1-2-6zm7 1-2 4 3 1 3-3m0 0 6 5m-8-2 5 4"/>',
 'research':'<path d="M8 3h8m-6 0v7l-6 9q-1 2 2 2h12q3 0 2-2l-6-9V3M7 16h10"/><circle cx="12" cy="13" r=".6"/>',
 'focus-tree':'<rect x="9" y="2" width="6" height="5"/><rect x="2" y="17" width="6" height="5"/><rect x="16" y="17" width="6" height="5"/><path d="M12 7v5H5v5m7-5h7v5"/>',
 'army':'<rect x="3" y="5" width="18" height="14"/><path d="M5 7l14 10M19 7L5 17"/>',
 'navy':'<circle cx="12" cy="4" r="2"/><path d="M12 6v14M7 10h10M3 14l1 4q8 8 16 0l1-4m-18 0 4 2m14-2-4 2"/>',
 'air-force':'<path d="M12 2l2 8 7 4v2l-7-2v5l2 2H8l2-2v-5l-7 2v-2l7-4 2-8z"/>',
 'logistics':'<path d="M3 7l9-4 9 4-9 4-9-4zm0 0v10l9 4 9-4V7m-9 4v10M7.5 5l9 4"/>',
 'industry':'<path d="M3 21V11l6-4v4l6-4v5h6v9H3zm14-9V3h3v9M6 16h2m3 0h2m3 0h2"/>',
 'manpower':'<circle cx="12" cy="5" r="2.5"/><path d="M8 20v-8q0-3 4-3t4 3v8m-4-6v7M4 10q-2 0-2 3v5m18-8q2 0 2 3v5"/>',
 'treasury':'<ellipse cx="9" cy="6" rx="6" ry="3"/><path d="M3 6v10c0 4 12 4 12 0V6M3 11c0 4 12 4 12 0"/><path d="M18 11v10m-2-8h4m-4 6h4"/>',
 'calendar':'<rect x="3" y="5" width="18" height="16"/><path d="M7 2v6m10-6v6M3 10h18M7 14h2m6 0h2m-10 4h2m6 0h2"/>',
 'pause':'<path d="M7 4h3v16H7zm7 0h3v16h-3z"/>',
 'play':'<path d="M7 3l14 9-14 9V3z"/>',
 'fast-forward':'<path d="M3 4l9 8-9 8V4zm9 0 9 8-9 8V4z"/>',
 'step':'<path d="M4 4l12 8-12 8V4zm15 0v16"/>',
 'settings':'<path d="M4 6h16M4 12h16M4 18h16"/><path d="M8 3v6m8 0v6m-6 0v6"/>',
 'help':'<circle cx="12" cy="12" r="9"/><path d="M9 8a3 3 0 0 1 6 0c0 3-3 3-3 6"/><circle cx="12" cy="18" r=".65"/>',
 'close':'<path d="M5 5l14 14M19 5L5 19"/>',
 'chevron-right':'<path d="M9 5l7 7-7 7"/>',
 'chevron-down':'<path d="M5 9l7 7 7-7"/>',
 'arrow-right':'<path d="M3 12h18m-7-7 7 7-7 7"/>',
 'search':'<circle cx="10" cy="10" r="6.5"/><path d="M15 15l6 6"/>',
 'zoom-in':'<circle cx="10" cy="10" r="6.5"/><path d="M15 15l6 6M7 10h6m-3-3v6"/>',
 'zoom-out':'<circle cx="10" cy="10" r="6.5"/><path d="M15 15l6 6M7 10h6"/>',
 'fit-world':'<path d="M3 9V3h6m6 0h6v6m0 6v6h-6M9 21H3v-6"/><circle cx="12" cy="12" r="4"/>',
 'layers':'<path d="M2 8l10-5 10 5-10 5L2 8zm0 5 10 5 10-5M2 18l10 5 10-5"/>',
 'terrain':'<path d="M2 20L9 5l5 9 3-5 5 11H2zm4-8 3 2 3-3"/>',
 'supply':'<path d="M3 10l9-7 9 7v11H3V10zm5 11v-8h8v8m-4-8v8"/>',
 'port':'<path d="M3 21h18M4 18V5h12v3H7v10M7 5l9 3 4 4m-4-4v6m-2 0h4"/>',
 'capital':'<circle cx="12" cy="12" r="9"/><path d="M12 5l2 4 5 1-4 3 1 5-4-3-4 3 1-5-4-3 5-1 2-4z"/>',
 'province':'<path d="M3 6l7-3 5 3 6-1-1 12-7 4-5-3-5 1V6z"/>',
 'mountain-pass':'<path d="M2 20L8 5l4 8 4-8 6 15M8 20l4-4 4 4"/>',
 'river-crossing':'<path d="M6 2q-4 4 0 8t0 8q-2 2-2 4m14-20q-4 4 0 8t0 8q-2 2-2 4M2 12h20M2 9v6m20-6v6"/>',
 'fortification':'<path d="M3 21V7h4V3h4v4h2V3h4v4h4v14H3zm7 0v-7h4v7"/>',
 'infantry':'<circle cx="12" cy="5" r="2"/><path d="M8 11l4-3 4 3m-4-3v8m0 0-4 5m4-5 4 5M5 13l14-4"/>',
 'artillery':'<circle cx="8" cy="17" r="4"/><path d="M8 13l9-9 4 3-10 9M11 17l8 4M4 21h16"/>',
 'cavalry':'<path d="M5 21l1-8 4-4V3l5 2 4 7-2 3-5-2-1 8H5zm8-13h.1"/>',
 'armor':'<path d="M3 13h18l1 5-3 3H5l-3-3 1-5zm5 0V8h8v5m-1-5 6-4M6 17h12"/>',
 'warship':'<path d="M2 16h20l-4 5H6l-4-5zm5 0V9h9v7M10 9V4h3v5m3 3h5M3 23q3-2 6 0t6 0t6 0"/>',
 'transport':'<path d="M2 16h20l-4 5H6l-4-5zm3-1V9h5v6m1 0V9h5v6m1 0V9h3v6M7 9V5h10v4"/>',
 'airfield':'<path d="M8 2h8v20H8zM12 4v2m0 3v2m0 3v2m0 3v1M3 7l18 10M3 17L21 7"/>',
 'attack':'<path d="M3 21l12-12-5-5 12-2-2 12-5-5M3 17l4 4"/>',
 'defend':'<path d="M4 4l8-2 8 2v8q0 6-8 10-8-4-8-10V4zm4 8 3 3 5-6"/>',
 'retreat':'<path d="M9 4L2 11l7 7M2 11h12q6 0 6 7v3"/>',
 'repair':'<path d="M21 3l-5 2-1 5 4 2 3-4q2 6-4 7l-3-1-7 7-4-4 7-7-1-3q1-6 7-4z"/>',
 'warning':'<path d="M12 2L1 21h22L12 2zm0 6v6m0 3v1"/>',
 'check':'<path d="M4 12l5 6L21 5"/>',
 'locked':'<rect x="5" y="10" width="14" height="11"/><path d="M8 10V6a4 4 0 0 1 8 0v4m-4 4v3"/>',
 'unlocked':'<rect x="5" y="10" width="14" height="11"/><path d="M8 10V6a4 4 0 0 1 8 0m-4 8v3"/>',
 'save':'<path d="M3 3h15l3 3v15H3V3zm4 0v7h10V3M7 21v-7h10v7"/>',
 'import':'<path d="M3 14v7h18v-7M12 2v13m-5-5 5 5 5-5"/>',
 'export':'<path d="M3 14v7h18v-7M12 15V2m-5 5 5-5 5 5"/>',
 'edit-map':'<path d="M3 6l6-3 6 3 6-3v8M3 6v15l6-3 3 1M9 3v15m6-12v5M13 20l1-4 6-6 3 3-6 6-4 1z"/>',
 'brush':'<path d="M8 15l10-12 4 4-12 10m-2-2q-5-2-6 6 6 0 8-4"/>',
 'select':'<path d="M4 2v18l5-5 4 7 3-2-4-7h8L4 2z"/>',
 'undo':'<path d="M9 3L2 10l7 7M2 10h12a5.5 5.5 0 0 1 0 11"/>',
 'redo':'<path d="M15 3l7 7-7 7m7-7H10a5.5 5.5 0 0 0 0 11"/>',
 'link':'<path d="M9 15l6-6m-7 4-2 2a4 4 0 0 0 6 6l3-3m1-7 2-2a4 4 0 0 0-6-6L9 6"/>',
 'contract':'<path d="M5 2h10l5 5v15H5V2zm10 0v5h5M8 11h9m-9 4h9m-9 4h5"/>',
 'route':'<circle cx="4" cy="4" r="2"/><circle cx="20" cy="20" r="2"/><path d="M4 6v10q0 4 4 4h10M9 4h7q4 0 4 4v6"/>',
 'coal':'<path d="M2 14l4-5 6 1 3-6 6 3 1 8-6 6-7-1-7-6zm4-5 3 11m3-10 4 11m-4-11 9-3M2 14l7 1 7-3 6 3"/>',
 'iron':'<path d="M3 7l14-4 4 5-14 4-4-5zm0 0v10l4 4 14-4V8M7 12v9m-4-9 4 4 14-4"/>',
 'oil':'<ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v14c0 4 14 4 14 0V5M5 10h14M5 16h14"/>',
 'food':'<path d="M12 22V3m0 5-5-3v4l5 3 5-3V5l-5 3zm0 8-5-3v4l5 3 5-3v-4l-5 3"/>',
 'timber':'<path d="M3 7l14-4 4 5-14 4-4-5zm0 0v10l4 4 14-4V8M7 12v9"/><ellipse cx="5" cy="14" rx="1" ry="3"/>',
 'rubber':'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M7 4l2 3m6 10 2 3M4 7l3 2m10 6 3 2"/>',
 'chemicals':'<path d="M8 2h8m-6 0v8l-6 10q-1 2 2 2h12q3 0 2-2l-6-10V2M7 16h10"/><path d="M10 18h4"/>',
 'equipment':'<path d="M2 10h20v11H2V10zm6 0V5h8v5M7 15v3m10-3v3M2 14h20"/>',
}
for name,body in ICONS.items(): svg(f'icons/{name}.svg',body,mono=True)

# Solid tactical symbols: legible at 12–18 px; visual grammar kept separate from chrome.
BRANCH={
 'infantry':'<path d="M3 4h18v16H3z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M4 5l16 14M20 5L4 19" stroke="currentColor" stroke-width="2"/>',
 'armor':'<rect x="3" y="5" width="18" height="14" fill="none" stroke="currentColor" stroke-width="2"/><ellipse cx="12" cy="12" rx="6" ry="4" fill="none" stroke="currentColor" stroke-width="2"/>',
 'artillery':'<rect x="3" y="5" width="18" height="14" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="3" fill="currentColor"/>',
 'cavalry':'<rect x="3" y="5" width="18" height="14" fill="none" stroke="currentColor" stroke-width="2"/><path d="M4 18L20 6" stroke="currentColor" stroke-width="2"/>',
 'naval':'<path d="M12 3v16M7 9h10M4 13q0 8 8 8t8-8l-4 2m-12-2 4 2" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="3" r="2" fill="none" stroke="currentColor" stroke-width="2"/>',
 'air':'<path d="M12 2l2 8 8 5v2l-8-2v4l3 3H7l3-3v-4l-8 2v-2l8-5z" fill="currentColor"/>',
 'support':'<rect x="3" y="5" width="18" height="14" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 12h8m-4-4v8" stroke="currentColor" stroke-width="2"/>',
 'headquarters':'<path d="M4 4h16v12H4V4zm0 12v6M7 10h10M12 7v6" fill="none" stroke="currentColor" stroke-width="2"/>',
}
for name,body in BRANCH.items(): svg(f'counters/symbols/{name}.svg',body)
for name,border,bg in [('standard',INK,PAPER),('selected',BRASS,'#f3ecd9'),('hostile','#8d3932',PAPER),('allied','#456f77',PAPER),('disabled','#929187','#e0dccf')]:
    body=f'<rect x="1" y="1" width="94" height="62" fill="{bg}" stroke="{border}" stroke-width="2"/><path d="M25 2v44M2 46h92" stroke="{LINE}" stroke-width="1"/>'
    if name=='selected': body+=f'<path d="M1 11V1h10m74 0h10v10m0 42v10H85M11 63H1V53" fill="none" stroke="{BRASS}" stroke-width="3"/>'
    svg(f'counters/frames/{name}.svg',body,96,64)
svg('counters/frames/compact.svg',f'<rect x="1" y="1" width="54" height="34" fill="{PAPER}" stroke="{INK}" stroke-width="2"/><path d="M18 2v32" stroke="{LINE}"/>',56,36)
STATUS={
 'engaged':'<path d="M5 3l16 16m-5-16L3 19m0-4 5 5m11-5-5 5"/>',
 'moving':'<path d="M3 12h17m-6-6 6 6-6 6"/>',
 'entrenched':'<path d="M3 7v10h18V7M6 13h12M9 7v6m6-6v6"/>',
 'low-supply':'<path d="M12 2L1 21h22zM12 8v6m0 3v1"/>',
 'damaged':'<path d="M3 5h18v14H3zM14 5l-5 7 6 1-4 6"/>',
 'ready':'<path d="M4 12l5 6L21 5"/>',
}
for name,body in STATUS.items(): svg(f'counters/status/{name}.svg',body,mono=True)

# Larger commodity artwork; polygonal construction instead of generative icon imagery.
resources={
 'coal':'<path d="M9 37l13-13 18 4 12-13 20 8 12 18-14 20-23 5-25-10-13-19z" fill="#454b48"/><path d="M9 37l20 7 11-16 7 20 25-25M29 44l-7 12m25-8v18m0-18 23 13m-23-13 37-7" fill="none" stroke="#252f30" stroke-width="2"/><path d="M22 24l18 4 12-13 20 8-25 25-7-20-11 16-20-7z" fill="#62655b" opacity=".65"/>',
 'iron':'<path d="M14 23l49-12 19 15-50 13z" fill="#bac1b4"/><path d="M14 23v32l18 16V39z" fill="#8b968f"/><path d="M32 39l50-13v32L32 71z" fill="#667875"/><path d="M14 38l18 15 50-13M14 48l18 15 50-13" fill="none" stroke="#d8d8c5" stroke-width="2"/>',
 'oil':'<path d="M27 20h42v44c0 13-42 13-42 0z" fill="#526668"/><ellipse cx="48" cy="20" rx="21" ry="8" fill="#8b9b93"/><ellipse cx="48" cy="64" rx="21" ry="8" fill="none" stroke="#303b3b" stroke-width="2"/><path d="M27 35q21 10 42 0m-42 17q21 10 42 0" fill="none" stroke="#c7c4ab" stroke-width="3"/><ellipse cx="59" cy="19" rx="4" ry="2" fill="#303b3b"/>',
 'food':'<path d="M48 72V15m0 17L29 20m19 27L25 34m23 26L29 48m19-16 19-12M48 47l23-13M48 61l19-13" fill="none" stroke="#8b7647" stroke-width="3"/><path d="M29 20q-8 16 14 19-1-17-14-19zm-4 14q-6 17 18 20-2-17-18-20zm4 14q-4 15 14 20 0-16-14-20zm38-28q8 16-14 19 1-17 14-19zm4 14q6 17-18 20 2-17 18-20zm-4 14q4 15-14 20 0-16 14-20z" fill="#bca264"/>',
 'timber':'<path d="M16 28l46-16 18 18-46 16z" fill="#c0ab7a"/><path d="M16 28v30l18 16V46z" fill="#a68c5b"/><path d="M34 46l46-16v30L34 74z" fill="#806f4e"/><ellipse cx="25" cy="49" rx="5" ry="10" fill="none" stroke="#5e624e" stroke-width="2"/><path d="M40 48l35-12M40 60l35-12M40 69l35-12" stroke="#c0ab7a"/>',
 'rubber':'<ellipse cx="48" cy="46" rx="31" ry="27" fill="#343f3d"/><ellipse cx="48" cy="42" rx="30" ry="26" fill="#5d6860"/><ellipse cx="48" cy="42" rx="16" ry="13" fill="#eee7d7"/><path d="M25 27l6 5m-11 6 7 2m-5 13 7-3m4 13 4-6m15 10-1-7m15 1-5-5m13-7-7-1m5-13-7 3m-1-11-5 5m-9-10v7" stroke="#303b3b" stroke-width="3"/>',
 'chemicals':'<path d="M36 12h24v9h-4v20l21 28q3 7-6 7H25q-9 0-6-7l21-28V21h-4z" fill="#d4dccb" stroke="#596b65" stroke-width="2"/><path d="M29 56h38l10 13q3 7-6 7H25q-9 0-6-7z" fill="#869b77"/><path d="M46 27v16L30 64" fill="none" stroke="#f4efe2" stroke-width="3"/><circle cx="49" cy="64" r="3" fill="#d9debf"/><circle cx="60" cy="68" r="2" fill="#d9debf"/>',
 'equipment':'<path d="M15 30h66v41H15z" fill="#63736b"/><path d="M15 30l8-10h50l8 10z" fill="#96a28e"/><path d="M35 20v-8h26v8M15 42h66" fill="none" stroke="#303b3b" stroke-width="3"/><path d="M28 38v12h8V38m24 0v12h8V38" fill="#b49a5a" stroke="#303b3b" stroke-width="2"/>',
}
for name,body in resources.items(): svg(f'resources/{name}.svg',body,96,88)

# Fictional identity palette and editable geometric charges. Do not map to realms implicitly.
charges={
 'sun':'<circle cx="0" cy="0" r="8"/><path d="M0-20v8M0 12v8M-20 0h8M12 0h8M-14-14l6 6M8 8l6 6M14-14l-6 6M-8 8l-6 6" fill="none" stroke="currentColor" stroke-width="3"/>',
 'crown':'<path d="M-19-10l8 6 11-13 11 13 8-6-4 25h-30z"/><path d="M-13 8h26" fill="none" stroke="#eee7d7" stroke-width="2"/>',
 'anchor':'<circle cy="-15" r="4" fill="none" stroke="currentColor" stroke-width="3"/><path d="M0-11v29M-10-4h20M-18 4q0 14 18 14T18 4M-18 4l5 4M18 4l-5 4" fill="none" stroke="currentColor" stroke-width="3"/>',
 'tower':'<path d="M-13-17h7v7h12v-7h7v34h-26z"/><path d="M-4 17V3h8v14" fill="#eee7d7"/>',
 'diamond':'<path d="M0-20l16 20L0 20-16 0z"/><path d="M0-11l8 11-8 11-8-11z" fill="#eee7d7"/>',
 'wheat':'<path d="M0 20v-39M0-8l-11-7m11 15-14-8m14 16L-11 1m11-9 11-7M0 0l14-8M0 8l11-7" fill="none" stroke="currentColor" stroke-width="4"/>',
 'cross':'<path d="M-5-19H5v14h14V5H5v14H-5V5h-14V-5h14z"/>',
 'star':'<path d="M0-20l5 13 14 1-11 9 4 14-12-8-12 8 4-14-11-9 14-1z"/>',
 'crescent':'<path d="M10-19a20 20 0 1 0 0 38A19 19 0 0 1 10-19z"/>',
 'chevrons':'<path d="M-20-2L0-18 20-2v9L0-9-20 7zm0 16L0-2l20 16v9L0 7l-20 16z"/>',
 'rosette':'<path d="M0-20l6 8 10-2-2 10 8 6-8 6 2 10-10-2-6 8-6-8-10 2 2-10-8-6 8-6-2-10 10 2z"/><circle r="5" fill="#eee7d7"/>',
 'mountain':'<path d="M-22 18L-4-19l12 21 5-10 9 26z"/><path d="M-4-19l-7 15 7-3 6 2z" fill="#eee7d7"/>',
}
flag_palettes=[('#496366','#dbcfaa'),('#8d4640','#e7d9bb'),('#3f5268','#c5aa61'),('#67714d','#e7d9bb'),('#aa854c','#293b3d'),('#545f59','#d5c4a1'),('#465b75','#eee7d7'),('#784e5b','#e3c881'),('#4b6871','#dfd5bf'),('#8a694b','#eee7d7'),('#606954','#ddd0ae'),('#665c79','#eee7d7')]
for i,(name,body) in enumerate(charges.items()):
    a,b=flag_palettes[i]
    field=f'<rect x="1" y="1" width="94" height="62" fill="{a}"/>'
    if i%3==0: field+=f'<path d="M1 1h21v62H1zM75 1h20v62H75z" fill="{b}" opacity=".35"/>'
    elif i%3==1: field+=f'<path d="M1 1h94v13H1zm0 49h94v13H1z" fill="{b}" opacity=".8"/>'
    else: field+=f'<path d="M1 1h94L1 63z" fill="{b}" opacity=".22"/>'
    field+=f'<g transform="translate(48 32)" fill="{b}" color="{b}">{body}</g><rect x="1" y="1" width="94" height="62" fill="none" stroke="{INK}" stroke-width="2"/>'
    svg(f'flags/fictional-{name}.svg',field,96,64)
    svg(f'insignia/{name}.svg',f'<g transform="translate(24 24)" fill="currentColor" color="currentColor">{body}</g>',48,48)

# Atlas motifs: sparse forms rather than a repeating backdrop that competes with borders.
tree='<path d="M0-14l-6 9h3l-7 10h8v5h4V5h8L3-5h3z" fill="#68775e" stroke="#455b4d" stroke-width=".8"/>'
mount='<path d="M-17 12L0-20l20 32z" fill="#d9d0ba" stroke="#7b7b6b" stroke-width="1"/><path d="M0-20l-4 15 6 5-1 12m-5-17-8 13m11-12 9 12m-5-14 7 14" fill="none" stroke="#92907b" stroke-width=".8"/>'
svg('terrain/forest-cluster.svg',''.join(f'<g transform="translate({x} {y}) scale({s})">{tree}</g>' for x,y,s in [(28,29,.8),(48,23,1),(65,34,.9),(18,48,.9),(40,47,1.1),(62,55,1),(81,51,.75)]),96,72)
svg('terrain/mountain-ridge.svg',''.join(f'<g transform="translate({x} {y}) scale({s})">{mount}</g>' for x,y,s in [(23,36,.8),(43,31,1),(66,39,.95),(37,55,.7),(76,55,.65)]),96,72)
svg('terrain/hills.svg','<g fill="none" stroke="#8a8b72" stroke-width="1.2"><path d="M5 48q15-31 34 0m-15-4q17-40 36 0m-11 9q17-30 39 0M10 58q14-8 25 0m22-2q14-8 25 0"/></g>',96,72)
svg('terrain/marsh.svg','<g fill="none" stroke="#68867f" stroke-width="1.2"><path d="M8 47h23m11 9h24m4-14h19M17 44V26m0 9-6-5m6 0 5-8M50 51V25m0 13-7-9m7 5 7-13M78 38V17m0 9-6-5m6 1 4-7"/></g>',96,72)
svg('terrain/desert.svg','<g fill="none" stroke="#b39b6d" stroke-width="1.2"><path d="M5 48q24-34 48 0m-28 10q26-32 58 0M15 49l12-7m12-2 8 8m-6 10 14-8m17-1 8 8"/></g>',96,72)
svg('terrain/farmland.svg','<g fill="none" stroke="#819074" stroke-width="1.2"><path d="M9 37l40-19 36 22-40 17zM18 41l38-18M27 46l38-17M36 51l38-17M26 30l35 21M37 24l35 21"/></g>',96,72)
svg('terrain/reef.svg','<g fill="none" stroke="#789ba2" stroke-width="1.2"><path d="M7 44q7-7 14 0t14 0m6-12q7-7 14 0t14 0m-32 23q7-7 14 0t14 0m3-9q7-7 14 0"/></g>',96,72)
svg('terrain/ice.svg','<g fill="#e0e9e4" stroke="#95aab0" stroke-width="1"><path d="M9 40l14-17 19 7-7 23-19-2zM49 31l15-12 18 13-5 15-21 2zM43 56l14-6 13 8-12 8z"/></g>',96,72)

random.seed(614)
for name,base,dot in [('paper','#eee7d7','#746b56'),('slate','#384342','#d3d0bc'),('sea','#a9c5ca','#526f75')]:
    body=f'<rect width="256" height="256" fill="{base}"/>'
    body+=''.join(f'<circle cx="{random.randrange(4,252)}" cy="{random.randrange(4,252)}" r="{random.choice([.35,.45,.6])}" fill="{dot}" opacity=".12"/>' for _ in range(650))
    if name=='paper': body+=''.join(f'<path d="M{x} {y}h{l}" stroke="{dot}" stroke-width=".4" opacity=".055"/>' for x,y,l in [(random.randrange(10,240),random.randrange(10,250),random.randrange(2,9)) for _ in range(130)])
    svg(f'textures/{name}-tile.svg',body,256,256)
svg('textures/occupation-hatch.svg','<path d="M-4 4l8-8M0 16L16 0m-4 20 8-8" fill="none" stroke="#303b3b" stroke-width="1" opacity=".28"/>',16,16)
svg('textures/fog-stipple.svg','<g fill="#384342" opacity=".3"><circle cx="3" cy="3" r=".8"/><circle cx="11" cy="9" r=".8"/><circle cx="4" cy="14" r=".8"/></g>',16,16)
svg('textures/sea-line-tile.svg','<path d="M-16 8q8-4 16 0t16 0t16 0t16 0M-16 24q8-4 16 0t16 0t16 0t16 0" fill="none" stroke="#526f75" stroke-width=".6" opacity=".16"/>',32,32)

# Point markers must be used in place of rich art at distant zoom.
markers={
 'town':'<path d="M5 12l7-6 7 6v8H5z" fill="#eee7d7" stroke="#303b3b" stroke-width="1.6"/><path d="M10 20v-6h4v6" fill="#303b3b"/>',
 'factory':'<path d="M3 20V11l6-4v4l6-4v5h6v8z" fill="#eee7d7" stroke="#303b3b" stroke-width="1.6"/><path d="M17 12V3h3v9" fill="#303b3b"/>',
 'port':'<circle cx="12" cy="12" r="10" fill="#eee7d7" stroke="#303b3b" stroke-width="1.6"/><path d="M12 5v13M8 9h8M6 13q0 6 6 6t6-6" fill="none" stroke="#303b3b" stroke-width="1.6"/>',
 'fort':'<path d="M4 4h5v3h6V4h5v16H4z" fill="#eee7d7" stroke="#303b3b" stroke-width="1.6"/><path d="M9 20v-8h6v8" fill="#303b3b"/>',
 'capital':'<circle cx="12" cy="12" r="10" fill="#303b3b" stroke="#eee7d7" stroke-width="1.5"/><path d="M12 5l2 4 5 1-4 3 1 5-4-3-4 3 1-5-4-3 5-1z" fill="#eee7d7"/>',
 'airfield':'<circle cx="12" cy="12" r="10" fill="#eee7d7" stroke="#303b3b" stroke-width="1.6"/><path d="M12 4l1.5 6 6 4v1.5L13 14v4l2 2H9l2-2v-4l-6.5 1.5V14l6-4z" fill="#303b3b"/>',
}
for name,body in markers.items():svg(f'markers/{name}.svg',body)

points=[]
for i in range(16):
    a=math.pi*i/8-math.pi/2;r=39 if i%4==0 else 24 if i%2==0 else 8
    points.append(f'{48+math.cos(a)*r:.2f},{48+math.sin(a)*r:.2f}')
svg('decorations/compass-rose.svg',f'<circle cx="48" cy="48" r="29" fill="none" stroke="{LINE}"/><polygon points="{" ".join(points)}" fill="{PAPER}" stroke="{INK}"/><path d="M48 9v78M9 48h78" stroke="{INK}" stroke-width=".8"/><circle cx="48" cy="48" r="3" fill="{INK}"/>',96,96)
svg('decorations/atlas-corner.svg',f'<path d="M3 61V3h58M8 48V8h40M13 31V13h18" fill="none" stroke="{LINE}" stroke-width="1"/>',64,64)
print('Vector assets:',len(list(ROOT.rglob('*.svg'))))
