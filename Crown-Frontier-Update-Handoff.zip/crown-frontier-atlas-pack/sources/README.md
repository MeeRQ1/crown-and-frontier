# Construction sources

`build_vectors.py` uses only Python standard-library modules. Run it to reproduce the editable SVG assets. Colors and construction geometry are intentionally visible in this source. It does not recreate images or fonts.

`build_pack.py` builds the tokens, documentation, component catalog, and manifest from the assets present. Install `requirements.txt` first; Pillow and fontTools with Brotli support are needed for asset metadata. Run `validate_pack.py` after rebuilding. The QA report also records a native SVG rendering and visual inspection performed during preparation; that rendering check is separate from the Python validator.

`landmark-prompts.json` records the four generated illustration prompts. Regenerating them will produce new images rather than byte-identical files.

WOFF2 files were made with `fontTools.ttLib.TTFont`: load the original supplied TTF, set `font.flavor = 'woff2'`, and save with a .woff2 suffix. No glyph subsetting or outline modifications were applied.

Menu extension: run `build_menu_assets.py` after `build_vectors.py` to create the additional menu motifs, small icons and nitrates illustration. Then run `build_pack.py` and `validate_pack.py`. `design/screen-redesign.md` is an authored screen specification, not overwritten by the build scripts.
