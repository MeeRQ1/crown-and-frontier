"""Offline asset validation and QA report. Requires Pillow and fonttools[woff]."""
from pathlib import Path
from html.parser import HTMLParser
import json,hashlib,xml.etree.ElementTree as ET
from PIL import Image
from fontTools.ttLib import TTFont

R=Path(__file__).resolve().parents[1]
m=json.loads((R/'manifest.json').read_text());errors=[]
if len({a['id'] for a in m['assets']})!=len(m['assets']):errors.append('Duplicate manifest ids')
for a in m['assets']:
 p=R/a['path']
 if not p.is_file():errors.append('Missing '+a['path']);continue
 if hashlib.sha256(p.read_bytes()).hexdigest()!=a['sha256']:errors.append('Hash mismatch '+a['path'])
 if p.suffix=='.svg':
  el=ET.parse(p).getroot()
  if 'viewBox' not in el.attrib:errors.append('No viewBox '+a['path'])
  for child in el.iter():
   if child.tag.split('}')[-1] in ('script','foreignObject'):errors.append('Unexpected executable SVG '+a['path'])
   for k,v in child.attrib.items():
    if k.lower().startswith('on') or ((k.endswith('href')) and not v.startswith('#')):errors.append('External/executable SVG '+a['path'])
 if p.suffix=='.png':
  im=Image.open(p);im.verify();im=Image.open(p)
  if 'A' not in im.getbands() or im.getchannel('A').getextrema()[0]!=0:errors.append('No clear transparency '+a['path'])
 if p.suffix in ('.ttf','.woff2'):
  f=TTFont(p);cm=f.getBestCmap()
  for code in list(range(32,127))+[0x2212]:
   if code not in cm:errors.append('Missing required font glyph '+a['path']+' '+str(code))
  f.close()
class Links(HTMLParser):
 def handle_starttag(self,tag,attrs):
  for k,v in attrs:
   if k in ('src','href') and v and not v.startswith(('#','http','data:')):
    if not (R/v).is_file():errors.append('Broken catalog link '+v)
Links().feed((R/'index.html').read_text())
pal=json.loads((R/'design/tokens.json').read_text())['colors']
def luminance(h):
 rgb=[int(h[i:i+2],16)/255 for i in (1,3,5)]
 c=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgb]
 return sum(a*b for a,b in zip(c,[.2126,.7152,.0722]))
def contrast(a,b):
 x,y=sorted([luminance(pal[a]),luminance(pal[b])]);return (y+.05)/(x+.05)
pairs=[('ink','ivory'),('ivory','slate'),('muted-on-ivory','ivory'),('muted-on-slate','slate'),('ink','brass'),('danger-on-ivory','ivory'),('danger-on-slate','slate'),('positive-on-ivory','ivory'),('positive-on-slate','slate'),('warning-on-ivory','ivory'),('warning-on-slate','slate')]
for a,b in pairs:
 if contrast(a,b)<4.5:errors.append('Text contrast under 4.5 '+a+'/'+b)
report='''# Asset-pack QA

Checked on 2026-10-06. This validates the delivered parts, not their integration into the game's renderer.

## Completed

'''
report+=f'- {len(m["assets"])} manifest assets checked against their SHA-256 hashes.\n'
report+=f'- {sum(a["path"].endswith(".svg") for a in m["assets"])} SVGs parsed; viewBoxes present; no scripts, event handlers or external asset references.\n'
report+=f'- All {sum(a["path"].endswith(".svg") for a in m["assets"])} individual vector assets rendered successfully with the native SVG renderer (Sharp/libvips). Icon light/dark, grouped part and menu-motif review images were inspected.\n'
report+='- Catalog asset and document links checked offline.\n'
report+='- Delivered PNGs decoded and checked for a real alpha channel with fully transparent pixels. Original raster images visually inspected separately.\n'
report+='- Bundled TTF and WOFF2 fonts decoded; basic Latin and minus glyphs checked. Corresponding font licenses included.\n'
report+='- No complete game screen or flattened gameplay interface included. Values in the small catalog component examples are explicitly sample data.\n'
report+='\n## Normal text contrast\n\nComputed from sRGB token values. This is not a blanket accessibility certification; integration must still check sizes, state combinations and map overlays.\n\n| Foreground | Background | Ratio |\n| --- | --- | --- |\n'
for a,b in pairs:report+=f'| `{a}` | `{b}` | {contrast(a,b):.2f}:1 |\n'
report+='''
## Still required in the game branch

- Real browser rendering of the catalog/components and actual game layouts. Local browser launch was unavailable during asset preparation; the HTML was not visually certified in Chromium, Firefox or Safari.
- Pixel-scale landmark readability, art sizing and zoom transitions. Rich raster masters are detailed; simple vector markers are the intended distant-zoom fallback.
- Real data binding for counters and status bars; labels, ownership colors, contrast and hit areas at all zoom tiers.
- Mobile/touch and keyboard play, long/localized names, empty and disabled states, and font loading under the deployed base path.
- Performance profiling and memory measurements on the requested huge maps; these are integration targets rather than claims made by this asset pack.
- Save compatibility, mechanics tests, scenario/editor validation and original faction mappings. No current repository code was modified or audited here.

Construction sources are reproducible for the vector files. Image prompts document generation, but repeating a prompt will not reproduce the raster images identically.
'''
report+='\n## Offline validator result\n\n'+('Passed: no errors.\n' if not errors else '\n'.join('- '+e for e in errors)+'\n')
(R/'QA_REPORT.md').write_text(report)
print(json.dumps({'assets':len(m['assets']),'errors':errors,'contrast':{a+'/'+b:round(contrast(a,b),2) for a,b in pairs}},indent=2))
if errors:raise SystemExit(1)
