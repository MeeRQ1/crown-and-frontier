# Whole-interface redesign specification

This extends the master update prompt and asset rules. Every existing player-facing surface is in scope, including screens discovered during the repository audit. The nine supplied screenshots are evidence of the current interface, not approved layout templates. They are bundled separately under `reference/current-ui/` and must not be shipped as runtime assets.

## Observed problems to resolve

The supplied views reuse a dark translucent container, serif heading, long explanatory paragraphs and card grids across unrelated tasks. Map labels remain visible behind panel content. The same global navigation appears in both the left rail and clipped panel tabs. In the Help view, a map tooltip is visible over the help panel. These are observable presentation issues; the screenshots alone do not establish simulation correctness or every interaction's behavior.

Replace this repeated shell with a coherent visual system and purpose-built information architecture. Keep the ivory atlas / warm slate command-room direction. Use opaque readable content surfaces; put texture behind information at restrained opacity. Give each task a useful composition rather than assigning it an unrelated theme or the same collection of rounded cards.

Keep one primary navigation model. Use local tabs only for genuine subdivisions of the active task. All destinations need a readable route at the available width; a partially clipped word is not a navigation strategy. Separate header, local actions and scrolling content. Support wide workspaces for dense trees or negotiations when useful, while restoring the player's map position and selection afterward.

## Screen-specific composition

| Screen | Purpose-built layout | Important information and behavior | Asset direction |
| --- | --- | --- | --- |
| Realm & Budget | Financial statement with an aligned revenue/expense register and a restrained adjacent reserve/administration summary | Show time periods, net balance, upkeep sources, debt conditions, food/manpower availability and actual controls. Connect a cost to its cause or inspector. Keep detailed rules in expandable explanations. | Budget/realm symbols, commodity art and a small realm-budget motif; live typography does the main work. |
| Industry & Trade | Production and stock ledger, with offer/commitment/delivery detail in a contextual workspace | Distinguish stock, capacity, monthly output, need, reserved amounts and actual trades. Make bottlenecks and applicable partner actions visible. The illustrated trade mockup is direction, not permission to fake contracts the simulation lacks. | Existing resource illustrations plus nitrates, industry/trade symbols and real route overlays. |
| Military | Operational roster with grouping by region/front where supported; selected formation inspector and map-linked orders | Comparable strengths, composition, readiness, supply, orders and upkeep. Give fleets and air wings appropriate existing controls. Empty wing/training states should explain relevant prerequisites, not resemble broken placeholders. | Branch symbols, counter layers, fleet/air markers, military motif; no decorative rank ribbons for fictitious data. |
| Research | Readable era/branch workspace with connected dependencies and a focused project inspector | Current project, progress, funding/rate, prerequisite, horizon-year cost, completion estimate and practical effect. Locked, available, selected, active and completed states must be distinct. Preserve view position when inspecting a node. | Meaningful existing branch/technology symbols; restrained research motif. Use code for nodes and dependency connectors. |
| National Focus | An authored branching plan with clear prerequisites, exclusions and a selected-focus inspector | National identity, strategic direction, time, switching consequence and connection to other systems. Distinguish a focus's effect from its flavor text. Show actual dependency/exclusion relationships, not merely cards arranged in columns. | Focus motif and suitable existing faction insignia. Faction-specific node motifs may be extended within this visual grammar. |
| Diplomacy | Compact faction index, selected faction briefing, agreement/commitment register and grouped proposal actions | Opinion/trust/alarm and relevant drivers; envoy commitments; treaty terms; acceptance reasoning and effects. Present metrics as a concise briefing rather than four oversized cards. Preserve actual information and action rules. | Existing faction identities, envoy/guarantee/contract symbols, diplomacy motif. |
| Wars & Peace | Campaign briefing in war, meaningful security/claim overview in peace; focused negotiation workspace | Participants, goals, fronts, costs, score components, occupation and peace consequences where modeled. Distinguish a claim from a current war and a settlement proposal from an accepted agreement. | Wars/peace motif, branch and defense/attack symbols, map-linked goals. |
| Victory | Comparable victory-route statements with thresholds, current position, blockers, hold durations and compact standings | Explain why a timer advances, pauses or regresses. Separate raw measures from percentage progress. Make the player's next meaningful constraint visible without pretending a victory outcome is guaranteed. | Victory symbol/motif and faction identities. Avoid decorative medals, arbitrary rings and fictitious accolades. |
| Chronicle | Chronological campaign register, with actionable links to related locations or entities | Audit what events are recorded. Use actual timestamps, concise event summaries and details; filters/search only where they help existing content. Do not invent historical events for atmosphere. | Chronicle and existing event-category symbols; typographic hierarchy over ornamental scrollwork. |
| How to Play / Help | Navigable field manual with a contents index, short articles, examples and contextual links | Explain current mechanics, vocabulary, consequences and controls. Replace large walls of prose with layered explanations. Keep the manual accurate after gameplay changes. Suppress underlying map hover/hit-testing where covered. | Help motif, existing mechanic symbols and live examples. No new visual style for the manual. |
| Setup, main menu and loading | Clear scenario presentation and deliberate campaign/start hierarchy | Compare actual maps, scale and faction identity; meaningful progress/error feedback. Use geographically truthful scenario previews. | Existing atlas parts and faction identities; create consistent missing scene art only if useful. |
| Settings, saves/import/export, confirmations and end-state dialogs | Compact task-specific utility layouts with predictable action order | Preserve saves; give validation and failure messages a clear recovery path; distinguish destructive or binding actions. Account for keyboard focus, dismissal and underlying map input. | Existing control/status icons; functional typography instead of large illustration. |
| Province, army, fleet, air, construction and other contextual inspectors | Object identity, current state, meaningful constraints, actions, then deeper explanation | Audit every inspector and nested modal actually present. Show what an action changes, keep selection continuity and keep map/order feedback synchronized. | Map markers, counters, branch and resource symbols; live state layers. |

Chronicle and the utility screens are scope requirements, but their full contents are not visible in these nine images. Inspect them in the actual game before deciding their detailed layout.

## Evidence supplied

| Reference file | Visible screen |
| --- | --- |
| `01-realm-budget.png` | Realm & Budget; administration continues below the viewport |
| `02-industry-trade.png` | Industry & Trade; commodity ledger continues below the viewport |
| `03-military.png` | Military, including Navy and Air, fleet roster and training area |
| `04-research.png` | Research, including era, Land warfare and Naval sections |
| `05-national-focus.png` | National Focus, including realm-specific branches |
| `06-diplomacy.png` | Diplomacy, including faction list, envoy and treaty actions |
| `07-wars-peace.png` | Wars & Peace in a peace state |
| `08-victory.png` | Victory; diplomatic route continues below the viewport |
| `09-help.png` | How to Play, scrolled to diplomacy, saves and information rules |

The images show UI for fleets, air wings and aviation research. Do not dismiss these views because the initial air-wing count is zero. Inspect their implementation and refine working existing systems accordingly. Conversely, screenshots are not proof that every advertised feature is complete. Verify behavior in code and in play.

The Help image describes public information for everyone. Preserve and verify the actual information model; the master prompt's warning about hidden data does not authorize introducing new fog-of-war rules.

## Asset integration and missing parts

The added `menu-emblems/` provides ten editable, transparent vector motifs. Use them sparingly, generally once in a section identity or meaningful empty state at roughly 40–72 px. They do not replace a label, a layout or an underlying function. Do not stamp them on every research node, card or row.

The new small icons cover realm, budget, envoy, guarantees, chronicle, victory, notifications and nitrates. Nitrates are shown in the current trade explanation; this asset adds no resource mechanic. Assign the real existing faction identity to a briefing and keep the generic fictional flags optional.

When the audit finds a needed icon or illustration absent from the pack, extend the existing vector language or create an appropriate consistent asset. Prefer code/SVG for small symbols, tree nodes, gauges, dividers and controls. Use raster illustration only where it contributes to an actual scene. No individually baked menu screens, node descriptions, values or labels.

## Coverage and acceptance

Create a screen inventory in the repository with: entry point, nested screens/dialogs, before-state evidence, design pattern, asset mapping, implemented states and verified interactions. Include surfaces not named above. A screen name alone does not prove it was redesigned.

For each surface, review real content in normal, crowded/long-label, empty, unavailable and relevant error states. Check wide and narrow layouts, scrolling, focus order, map input isolation and return-to-selection behavior. For research/focus, test dependency navigation; for diplomacy/peace, test actual proposals; for ledgers, test a shortage or commitment; for utility dialogs, test failure and recovery.

Use representative screenshots to demonstrate all major screen families, with short interaction checks for each. Preserve the working action paths during redesign and test intentional gameplay changes separately. No original generic shell may be left untouched simply because the map and trade view look better.
