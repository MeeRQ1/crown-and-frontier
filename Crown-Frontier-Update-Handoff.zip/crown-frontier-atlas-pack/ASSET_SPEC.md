# Asset specification

Menu extension v1.1 adds ten 96 × 96 monochrome motifs, eight 24 × 24 UI icons and one 96 × 88 nitrates illustration. The motifs are suitable for sparse 40–72 px use in screen identities; preserve a text label. See `design/screen-redesign.md`.

All paths are relative to the pack root. `manifest.json` lists exact files and hashes. SVG source is the editable master. Raster master PNGs are delivered unmodified from generation; transparent margins and style require inspection at final display scale.

| Family | Master size | Intended use |
| --- | --- | --- |
| UI icons | 24 × 24 viewBox | 20–24 px, 1.7-unit stroke, inline or masked |
| Resource art | 96 × 88 | 40–56 px in commodity registers |
| Fictional flags | 96 × 64 | 3:2 ratio, 30 × 20 px or larger; full-color |
| Insignia | 48 × 48 | Monochrome charges for identity composition |
| Standard counter frame | 96 × 64 | Native screen pixels; expand layout for long values |
| Compact counter frame | 56 × 36 | Summary only; one small identity and branch symbol |
| Tactical symbols/status | 24 × 24 | 12–24 px, live labels explain branch/status |
| Terrain motifs | 96 × 72 | Sparse, cached, no interactive meaning by themselves |
| Map point markers | 24 × 24 | Low-detail substitutes for rich landmarks |
| Surface tiles | 256 × 256 | Repeat over a flat matching base color; no heavy filters |
| Hatch/stipple | 16 × 16 | Occupation/fog overlay, pair with legend |
| Sea lines | 32 × 32 | Optional sparse sea texture; remove if routes compete |
| Rich landmarks | See manifest | 64–128 px at local zoom; lazy-loaded |

## Counter slots

Coordinates are in the standard frame's viewBox. Chrome is not a functional widget.

| Slot | x, y | width × height | Rule |
| --- | --- | --- | --- |
| Identity flag | 3, 3 | 20 × 14 | Preserve 3:2 flag aspect; center vertically |
| Branch symbol | 41, 6 | 24 × 24 | Dark mono symbol, plain background |
| Strength text | 28, 30 | 64 × 14 | Center; localizable compact format plus exact tooltip |
| Readiness bars | 4, 51 | 88 × 7 | Two bars separated by 4 px; actual metric mapping disclosed |
| Optional status | Outside right edge | 16 × 16 | Expand hit area and collision box; never hide another counter |

Compact frame: identity region x=2–17, summary region x=20–52; branch at 26,6 with 20 × 20 footprint. Omit bars and numeric text at this scale. Use a tooltip/inspector for details. Fit counts from the real simulation; no illustrative values in production.

Use `styles/components.css` as a reference, adapting to the repository's framework. It is intentionally scoped and does not globally reset the application. Numbers, bars and flag assignments in the catalog are labelled sample component content.

## Tokens and contrast

Token colors are separated for text on ivory and on slate. Never place dark positive/danger text on slate or light positive/danger text on ivory. `QA_REPORT.md` records measured normal-text contrast for the intended pairs. Thin decorative rules and pastel faction fills are not text colors or sufficient interaction boundaries by themselves. Use darker outlines for controls and shape/label redundancy for military states.

## Display limits

Use the generated landmark transparency bounds to align the visible object, not merely the center of the full PNG canvas. Large empty margins are retained in the master; make appropriately sized exports in the implementation branch if needed. Use vector point markers until an illustration has enough visible pixels to read. These raster masters are not certified to be pixel-perfect isometric sprites or mutually aligned animation frames.

Surface textures place no features across the outer tile boundary except the deliberately periodic sea lines/hatch. They tile without cut fragments; repeated grain is still a repeated pattern, so apply lightly. Contours, roads, shorelines, coast hatching and border strokes should be generated from geometry in the renderer, not assembled from this pack's decoration.
