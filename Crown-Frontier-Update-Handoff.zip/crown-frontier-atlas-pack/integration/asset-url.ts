/** Supply the actual deployment base from your build tool. No root-path assumption. */
export function assetUrl(deploymentBase: string, relativePath: string): string {
  if (/^(?:[a-z]+:|\/)/i.test(relativePath) || relativePath.split('/').includes('..')) {
    throw new Error('Asset path must be a relative pack path');
  }
  return `${deploymentBase.replace(/\/?$/, '/') }assets/crown-frontier-atlas/${relativePath}`;
}
// Vite example only, after copying pack to public/assets/crown-frontier-atlas/:
// const coal = assetUrl(import.meta.env.BASE_URL, 'resources/coal.svg');
// For monochrome SVGs, inline trusted bundled SVG or set CSS mask-image to this URL.
// External <img> does not inherit parent currentColor. Use it for multicolor assets.
