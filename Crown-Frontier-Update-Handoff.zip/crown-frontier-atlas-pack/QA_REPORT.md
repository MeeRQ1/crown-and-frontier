# Asset-pack QA

Checked on 2026-10-06. This validates the delivered parts, not their integration into the game's renderer.

## Completed

- 175 manifest assets checked against their SHA-256 hashes.
- 165 SVGs parsed; viewBoxes present; no scripts, event handlers or external asset references.
- All 165 individual vector assets rendered successfully with the native SVG renderer (Sharp/libvips). Icon light/dark, grouped part and menu-motif review images were inspected.
- Catalog asset and document links checked offline.
- Delivered PNGs decoded and checked for a real alpha channel with fully transparent pixels. Original raster images visually inspected separately.
- Bundled TTF and WOFF2 fonts decoded; basic Latin and minus glyphs checked. Corresponding font licenses included.
- No complete game screen or flattened gameplay interface included. Values in the small catalog component examples are explicitly sample data.

## Normal text contrast

Computed from sRGB token values. This is not a blanket accessibility certification; integration must still check sizes, state combinations and map overlays.

| Foreground | Background | Ratio |
| --- | --- | --- |
| `ink` | `ivory` | 10.67:1 |
| `ivory` | `slate` | 8.32:1 |
| `muted-on-ivory` | `ivory` | 5.01:1 |
| `muted-on-slate` | `slate` | 5.88:1 |
| `ink` | `brass` | 5.86:1 |
| `danger-on-ivory` | `ivory` | 5.52:1 |
| `danger-on-slate` | `slate` | 5.44:1 |
| `positive-on-ivory` | `ivory` | 5.44:1 |
| `positive-on-slate` | `slate` | 5.67:1 |
| `warning-on-ivory` | `ivory` | 5.79:1 |
| `warning-on-slate` | `slate` | 6.28:1 |

## Still required in the game branch

- Real browser rendering of the catalog/components and actual game layouts. Local browser launch was unavailable during asset preparation; the HTML was not visually certified in Chromium, Firefox or Safari.
- Pixel-scale landmark readability, art sizing and zoom transitions. Rich raster masters are detailed; simple vector markers are the intended distant-zoom fallback.
- Real data binding for counters and status bars; labels, ownership colors, contrast and hit areas at all zoom tiers.
- Mobile/touch and keyboard play, long/localized names, empty and disabled states, and font loading under the deployed base path.
- Performance profiling and memory measurements on the requested huge maps; these are integration targets rather than claims made by this asset pack.
- Save compatibility, mechanics tests, scenario/editor validation and original faction mappings. No current repository code was modified or audited here.

Construction sources are reproducible for the vector files. Image prompts document generation, but repeating a prompt will not reproduce the raster images identically.

## Offline validator result

Passed: no errors.
