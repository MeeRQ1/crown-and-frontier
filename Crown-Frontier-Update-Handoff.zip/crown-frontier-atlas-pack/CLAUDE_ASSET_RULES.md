# Implementation rules for Claude

Use this pack with the main Crown & Frontier update prompt. Read `README.md`, `design/tokens.json`, `ASSET_SPEC.md`, `PROVENANCE.md`, and the manifest before integration. The current game repository is the authority for implemented mechanics and faction identity; this pack has not inspected that code.

## 1. Deliver one coherent update

Work through audit, integration, refinement and verification in one implementation pass on an isolated branch. Internal checkpoints are required; do not turn every checkpoint into a request for approval. Finish a reviewable pull request with screenshots, validation and known limitations. Do not merge or deploy unless the user has authorized it.

This pack does not authorize additional game systems. Deepen and polish what already exists. The requested new map content remains a huge Earth map, a large Europe map and a large fictional map, plus refinement of the existing map-making tools. Inspect the repository to establish what is actually present before writing the plan.

## 2. Art direction is the first priority

Build an ivory strategic atlas inside warm slate command furniture. Use the palette and font families supplied. Keep the map dominant. Use brass for a focused selection or primary action, brick red for danger, sage for favourable values, and blue-grey for water and routes. Brass should not decorate every divider.

The map should feel like an authored geographical document: coherent coastlines, restrained engraved landforms, fine borders, sensible roads, legible labels, muted political washes. Geometry, shorelines, ownership, occupation, routes and text are generated from live map data. Do not substitute a huge painting for the playable world.

Treat the reference as direction, not a literal tracing. Solve the real game's content density. Panel shapes, spacing and breakpoints may change when necessary for readable controls. Keep a record of meaningful deviations and their purpose.

## 3. Use assets by role

- Small icons are monochrome `currentColor` SVGs. Inline trusted bundled SVGs or use CSS masks. An external SVG `<img>` cannot inherit its parent's color. Multicolor flags and illustrations may use normal `<img>` or cached canvas images.
- Preserve SVG viewBoxes and optical margins. Do not normalize every asset to the same cropped bounds. Show resources at roughly 40–56 px; UI symbols at 20–24 px; keep a 44 px hit area for touch controls.
- Counter chrome is intentionally empty. Add faction flag, branch symbol, strength and real status bars as live layers. Do not bake numbers or nation names into images. A status shape must retain a text explanation or tooltip.
- The fictional flags are optional identity ingredients, not historical flags and not a mandate to rename or recolor existing realms. Explicitly map them only where suitable. Real-world scenarios require accurate era-appropriate identity choices, separate from this generic flag set.
- Rich landmark PNGs are visual location markers, not interface icons. Use the simple vector marker at distant zoom. A port or factory illustration must correspond to a real location in the simulation. Suppress overlapping artwork.
- Terrain motifs are sparse accents. Orient ridges along real geography, distribute forests deterministically, and vary scale modestly. Avoid evenly stamped rows of the same symbol. Never obscure borders, movement routes or labels.
- No new navy, air-force, resource or research feature is implied by a symbol being available. Do not invent mechanics to justify unused art.

## 4. Typography and hierarchy

Use **Barlow Condensed 600** for short titles and command headings. Use **Source Sans 3** for body copy, tables, tooltips and values. Use tabular lining numerals and right-align comparable quantities. No artificial condensation, outlined letters, blanket all-caps body copy, tiny condensed tables, or gratuitous letter spacing.

Aim for 16 px normal text and at least 14 px in dense tables. Render map labels at a readable screen-pixel size rather than letting world scaling shrink them indefinitely. Move, shorten or suppress lower-priority labels before allowing collisions. Separate place names from realm names in size, weight and placement, not elaborate effects.

## 5. Interface craft

Follow `design/screen-redesign.md` for every existing menu and dialog, including surfaces discovered in the audit. Give each task a suitable composition; leave no old generic panel shell untouched. Menu motifs are optional header punctuation, not a replacement for redesigned information architecture.

Build a clear status rail, a dominant map, task-oriented inspector panels, and compact contextual commands. Use squared panels, thin rules, aligned rows and occasional ivory inset registers. Selectors and controls must feel related across trade, diplomacy, army and research views. Use existing meaningful data; do not add empty dashboard blocks for visual balance.

Communicate real consequences before commitment: cost, time, dependencies, likely benefit, confidence and uncertainty where the game models them. Give rejected actions an actionable reason. Trade should make the player's shortage, commitment, partner offer and delivery outcome understandable. Connect economic constraints, military readiness and research choices to the systems already implemented; do not claim depth that the simulation lacks.

Disabled, selected, focused, hovered, loading and empty states need deliberate treatment. Use label/icon/shape redundancy so color is never the only signal. Preserve keyboard navigation and a visible focus ring. Touch must support the same tasks without hover-only details or accidental map movement.

## 6. Texture restraint and map scales

Texture belongs behind content, never in type or chart lines. The supplied tiles have subtle marks; blend them over a flat token color at the suggested opacity. Do not apply multiple full-strength grain layers. Avoid CSS filters and live noise on every province.

At world view, show realm identity and essential geography. At regional view, introduce collision-checked province labels and simple landmarks. At local view, reveal richer artwork where it is useful. Base transitions on projected screen size and measured readability. Fixed zoom values must be fitted to the current renderer.

For Earth and Europe, use consistent source geography, projection and adjacency. Document data provenance and licenses. The editor must export structured playable maps, validate graph connectivity and scenario data, and report specific problems. Do not call a decorative map import a working custom-map editor.

## 7. Performance and technical integration

Serve locally bundled fonts and assets with correct GitHub Pages base paths. Keep the static browser build usable without a mandatory external service. Lazy-load landmark art after first paint; use mip levels or reduced derivatives only when profiling shows a benefit. Cache rasterized SVGs by size, style and device pixel ratio. Never decode or rasterize them per frame.

Only draw visible provinces, labels and markers. Profile the huge Earth scenario as well as small campaigns. Measure frame work, simulation ticks, memory, startup and save/load on declared hardware. Use workers or architectural changes when measurements justify them, not by reflex. Preserve save compatibility or provide a documented migration and backup route.

## 8. Acceptance before handoff

Verify the current project's build, type checks and meaningful tests. Play through trade shortages, war orders, diplomacy, research decisions, map editing and save reload wherever those features exist. Test the long labels, empty states and disabled actions that tidy demo screenshots miss.

Inspect actual desktop and narrow touch layouts at multiple zoom tiers and browser scales. Check keyboard focus, contrast, asset errors, label collisions, ownership readability and all deployment subpaths. Include component states and real game screenshots in the pull request. Explain what was not tested. Automated checks alone do not establish that the art direction works in play.

Do not describe the update as complete while supplied assets remain merely copied into a folder. The player must encounter the coherent direction throughout setup, map, inspectors, commands and feedback. Improve rough pieces against the same rules rather than falling back to generic cards or introducing another unrelated visual style.
