# Crown & Frontier — Ivory War Atlas asset pack

Individual assets for the approved **light ivory atlas / warm slate command room** direction. This is a modular production starting point, not a baked game screen and not an implemented game update.

## Start here

1. Unzip the folder and open `index.html` to inspect the asset catalog and small component examples.
2. Give Claude this folder, your main update prompt, and `CLAUDE_ASSET_RULES.md`.
3. Claude should inspect the current repository, map each asset to existing features, then integrate and verify the full update in one working branch.

Copy the runtime files you actually use into the repository. Keep documentation, construction sources, license notices, and the manifest with the project; the whole gallery need not ship to players. Paths in the catalog are relative and work after unzipping.

## Contents

- `icons/`: navigation, resources, military, map, and editor symbols; editable 24 px SVGs.
- `resources/`: larger vector commodity illustrations, including existing nitrates.
- `menu-emblems/`: ten optional editable section motifs for the full menu overhaul.
- `design/screen-redesign.md`: screen-specific compositions, screenshot observations and coverage acceptance rules.
- `counters/`: empty frames, branch symbols and status overlays. Values remain live.
- `flags/` and `insignia/`: twelve generic fictional identities. No automatic faction assignment.
- `terrain/`, `markers/`, `decorations/`, `textures/`: atlas components with separate low-detail forms.
- `landmarks/`: four separate transparent engraved raster illustrations.
- `fonts/` and `licenses/`: self-hosted Barlow Condensed and Source Sans 3 with their OFL notices.
- `design/`, `styles/`, `integration/`: tokens, scoped component CSS, path helper and technical rules.
- `manifest.json`: per-asset paths, sizes, origins and SHA-256 hashes.
- `sources/`: vector authoring scripts and image-generation prompts.
- `QA_REPORT.md`: what was actually checked, plus integration checks still required.

The approved look is expressed through clear geometry and purposeful hierarchy. Texture and ornament are secondary. No royal serif headings, glass panels, oversized rounded cards, decorative dashboard statistics or baked interface lettering.
