# Crown & Frontier — update handoff

1. Read `Crown-Frontier-Master-Update-Prompt.md`. This is the complete release brief.
2. Make `crown-frontier-atlas-pack/` available in the connected game repository so Claude can read and use the individual assets. Preserve the internal folder structure.
3. Paste the master prompt into Claude, or attach the master file and ask Claude to read it fully and implement it. Use this master brief in place of the older update prompts.
4. Let Claude complete its internal implementation and verification work. Review the resulting pull request and test the game before authorizing a merge/deployment.

The ZIP is a transfer bundle. Extract it to access the individual files. The asset folder includes an `index.html` catalog, integration rules, provenance, fonts, source files and a manifest. Runtime assets contain no flattened game screens. `reference/current-ui/` contains nine separately labelled before-state screenshots for redesign coverage; these must not ship as game assets. Read `design/screen-redesign.md` inside the asset pack for the whole-menu specification.

Suggested opening message:

Read the attached Crown-Frontier-Master-Update-Prompt.md in full and implement it in the connected Crown & Frontier repository. The companion crown-frontier-atlas-pack folder contains the approved asset parts and design rules; read and integrate them as directed. This master prompt supersedes my earlier update briefs. Complete the implementation and verification in one working pass, then give me a reviewable pull request.
