# Crown & Frontier — Atlas & Strategy Refinement Update

Implement this update in the existing Crown & Frontier repository. The game already works and has an enjoyable core. This update must give it a distinctive visual identity and substantially deepen the systems it already has. Deliver the working implementation, not just a design proposal, mockups, copied assets, or a roadmap.

The long-term ambition is the strategic depth, replayability and engagement of a game such as Hearts of Iron IV, with Crown & Frontier's own identity and approachable presentation. This is one deliberate step toward that ambition, not a request to reproduce another game or cram every possible feature into this release.

## 1. Priorities and scope

Use this order to resolve competing design choices:

1. **Intentional art direction and interface craft.** Transform the entire experience around the approved ivory atlas / slate command-room direction.
2. **Depth and refinement of existing systems.** Trade and the economy are particular priorities, alongside warfare, diplomacy, research and AI.
3. **Three substantial new campaign maps and better map making.** Huge Earth, large Europe, and a large original fictional world.
4. **Stability, performance and compatibility.** These are acceptance requirements throughout, not work deferred until after the release.

Deepen existing systems rather than stacking more shallow feature categories. You may improve rules, formulas, internal data models, system connections and interfaces when they produce better strategic decisions. Explain material gameplay changes in the documentation and PR. Fix bugs wherever necessary. Preserve working behavior that does not need to change.

Do not add unrelated standalone systems such as espionage, a new political simulation, monetization, multiplayer or elaborate character mechanics. Do not add navy or aviation merely because assets for them exist; refine them if they are already implemented. Complete missing pieces of the requested map-authoring workflow where necessary.

Keep the browser version and existing static deployment working. This update does not include an engine migration, desktop conversion or a required backend.

## 2. Audit the actual project first

Start from the latest `main`, preserve any existing user work, and create an isolated working branch. Inspect the game in a real browser before designing. Read the current architecture, map format, saves, tests and deployment configuration.

Record a concise baseline: which systems are functional, which are placeholders, which are disconnected, the current largest map, obvious interaction defects, and measured performance on declared hardware. Do not assume an earlier description proves a feature is implemented.

Write a compact implementation plan and a system-refinement matrix. For each major system, identify its current decision, why that decision is shallow or unclear, what changes will improve it, how it connects to other existing systems, and how you will verify the result.

Proceed autonomously through the implementation. Use internal checkpoints to catch problems early; do not stop after each phase to ask whether you should continue. Ask only when a consequential decision cannot reasonably be resolved from this brief or the project.

## 3. Use the attached art pack

The accompanying `crown-frontier-atlas-pack/` contains 165 editable SVG assets, four separate transparent landmark illustrations, fonts, tokens, component references and integration instructions.

Read these before integration:

- `CLAUDE_ASSET_RULES.md`
- `ASSET_SPEC.md`
- `design/tokens.json`, `design/map-rendering.json` and `design/screen-redesign.md`
- `manifest.json`, `PROVENANCE.md` and `QA_REPORT.md`

Open `index.html` to inspect the individual parts. This master prompt defines release scope; the asset rules define visual and technical usage. The current repository establishes implemented behavior. Where this prompt intentionally changes gameplay, the requirement is to document and validate the change, not freeze the old rules.

Treat the pack as an editable material library. Integrate suitable parts, refine rough ones, and make consistent missing variants where needed. Do not force every asset into the game. Do not add mechanics to justify an unused symbol. Preserve font and other applicable attribution notices.

The nine files under `reference/current-ui/` document the existing menus. Use them to identify redesign targets and compare coverage; they are not approved styling references or runtime artwork. Follow the screen-specific specification in `design/screen-redesign.md`.

If the approved final mockup is attached, use it as a visual anchor for palette, atmosphere and hierarchy. It is not a literal layout specification or an image to use as the playable interface.

## 4. Art direction: an authored strategic atlas

Combine the compositional clarity of an **industrial command room** with the cartographic character of an **imperial war atlas**:

- Light ivory land and register surfaces.
- Warm slate controls that are dark enough to frame the map without overwhelming it.
- Blue-grey water, muted political washes and restrained engraved geography.
- Brass for selected states and important primary actions, brick red for danger, sage for favourable conditions.
- Barlow Condensed for short headings; Source Sans 3 for interface text and numerical information. Use aligned tabular figures.
- Crisp panel construction, thin rules, aligned registers and purposeful iconography.

Give the game character through composition, typography, map quality and precise interaction design. Avoid generic dashboard cards, excessive gold, glass effects, oversized rounded containers, medieval serif headings, decorative statistics and arbitrary badges. Texture should support the atlas quietly; visual noise does not create authorship.

Keep map geometry, ownership, labels, routes, selections and numerical values live. Never bake gameplay information into a decorative background. Illustrations must depict actual map locations and appear only at zoom levels where they read clearly.

Refine the implementation against real game content. Adjust spacing, component proportions and breakpoints when needed; keep the approved visual grammar coherent. Record significant departures and their purpose.

## 5. Carry the direction through the whole interface

Redesign every existing player-facing surface, including those not named in this brief. The scope explicitly includes Realm & Budget, Industry & Trade, Military and its Navy/Air/training views, Research, National Focus, Diplomacy, Wars & Peace, Victory, Chronicle, How to Play/Help, main menu, loading/setup, campaign selector, HUD, notifications, settings, saves/import/export, confirmations, end-state dialogs, and all province/army/fleet/air/construction or other inspectors and nested dialogs present in the game.

Create a screen inventory from the repository and actual browser navigation. Record each entry point, nested states/dialogs, before-state evidence, redesign approach, asset needs and verified interactions. The named list is a minimum, not permission to skip another screen.

The screenshots show repeated translucent card layouts, map text bleeding through content, clipped global tabs and an underlying map tooltip over Help. Resolve these presentation and input-layer problems. Use opaque readable surfaces, deliberate scroll regions and one clear primary navigation model. Local tabs should represent real subdivisions rather than repeat the entire global menu.

Give each screen its own task-appropriate composition within the common visual system: financial registers for budgets, production/trade ledgers, operational military rosters, navigable research and focus trees, diplomatic briefings, campaign/peace reports, comparable victory routes and a structured field manual. Chronicle should read as a campaign record. Shared colors and controls do not require every screen to share the same card-grid layout.

Use the supplied menu motifs and symbols where useful; create coherent missing variants when needed. Keep illustrations subordinate to real information. Tree nodes, ledgers, metrics, titles and actions remain live code and text. Do not merely add an emblem to the existing generic panels and call them redesigned.

Dense trees or negotiations may use a wider dedicated workspace when that improves usability. Restore map position and selection afterward. Keep the map dominant in ordinary campaign play and preserve navigation/context continuity throughout.

Make the map dominant, navigation consistent, selections obvious and primary actions easy to find. Distinguish stockpiles, net flows, committed amounts, capacity and urgent problems. Use units and time periods consistently.

Before a consequential action, explain its actual cost, timing, dependencies and relevant trade-offs. Forecasts must expose assumptions and uncertainty. Give unavailable actions specific reasons and a route to resolve them. Do not reveal hidden information or imply guarantees the simulation cannot provide.

Use progressive disclosure: show the decision first, then let players inspect the underlying calculation. Depth must come from interacting constraints and consequences, not an intimidating number of buttons. Routine inspection and navigation should remain easy.

Implement focused, hovered, selected, disabled, empty, loading and error states deliberately. Notifications should be informative and prioritized without repeatedly interrupting play. Preserve keyboard access, visible focus, reduced motion and usable touch interaction. Essential information must not require hover, and essential distinctions must not rely on color alone.

## 6. Trade and the economy: make planning matter

Trade must become a credible strategic instrument rather than a simplistic exchange button. Audit what is already modeled and strengthen the actual simulation before adding decorative ledgers.

Make these relationships understandable and consequential:

- Domestic output, consumption, production commitments and military needs.
- Available stock versus reserved stock; actual flows versus pending orders.
- Shortages, reserves, surplus, bottlenecks and sustainable production.
- Partner availability, price, quantity, duration and the terms of a commitment.
- Delivery time, route or capacity constraints, interruption and dependence where relevant to the implemented transport model.
- How trade terms, access, war and diplomatic commitments affect the economy.

Players should compare offers, anticipate shortages, weigh dependence against self-sufficiency, and judge whether a commitment leaves them vulnerable elsewhere. Give cancellation, failed delivery and unsustainable commitments consistent rules with clear feedback.

Use the current resource and production model as the foundation. Add supporting rules only where needed to make it coherent. Avoid proliferating commodities or weapon tiers that create bookkeeping without new decisions. Eliminate circular arbitrage, duplicate deliveries, impossible resource creation and other exploits. Define and test the accounting invariants appropriate to the implemented model.

Forecasts should use the real simulation and state their assumptions. Separate known commitments from speculative future changes. The AI must use the same economic constraints and trade accounting as the player.

## 7. Refine warfare and existing military branches

Improve the current relationship between force composition, movement, terrain, supply, equipment, readiness and economic capacity. Existing military branches should have distinct uses, weaknesses and operational costs rather than merely different names or damage multipliers.

Make geography and preparation matter. Attacking, defending, concentrating forces, reinforcing, retreating and extending supply should have intelligible trade-offs. Orders should be reliable, readable and inspectable. Explain stalled movement and ineffective operations.

The supplied Military screenshot includes fleets, air wings, blockades and an aviation unlock. Audit these existing views and their mechanics; an initial count of zero air wings is not evidence that aviation is absent. Where naval or air systems are implemented, improve their interaction with the current war and transport systems. Refine mission selection, operational limits, interception or support only as appropriate to their established mechanics. Do not build entire new branches in this release if they are absent.

Improve battle explanations and forecasts without disclosing hidden enemy data. The player should be able to understand an outcome and respond to it.

Check peace negotiations, occupation and territorial concessions across different map and realm sizes. Investigate runaway conquest and scale-dependent loopholes; do not assume a large concession is automatically a bug or solve imbalance with arbitrary caps alone. Changes need a demonstrated problem and a coherent rule.

## 8. Diplomacy, research and strategic choice

**Diplomacy:** make existing agreements, relations, access, alliances, war decisions and peace terms reflect credible incentives and commitments. Explain why a proposal is accepted or rejected. Evaluate the current effects of power, economic dependence, border danger, war exhaustion and past actions wherever the model supports them. Remove obviously exploitable or meaningless offers. Diplomatic paths should be viable where the game's victory design supports them.

**Research and focus:** refine the systems already present into readable choices with prerequisites, opportunity costs, timing and practical effects. A tree is only useful if its branches create different strategies. Improve weak or automatic choices, disconnected bonuses, unclear requirements and the presentation of dependencies. Explain how a choice affects production, warfare, trade or other implemented systems. Avoid extending trees with filler nodes to create the appearance of complexity.

**Campaign balance:** preserve multiple workable strategies and faction identities. Strong starting positions may be intentional, but investigate choices that dominate across circumstances or make whole systems irrelevant. Use evidence before retuning victory thresholds, costs or map-specific scaling.

The desired experience is thoughtful strategy: the player weighs competing goals, commits resources, anticipates consequences and adapts. Not every click needs to be difficult; important decisions should matter.

## 9. Improve AI behavior across existing systems

Refine the AI's planning and execution for the systems above. It should assess economic sustainability, priorities, supply, threats, multiple fronts, commitments and war readiness, then act consistently on that assessment.

Fix idle armies, pointless wars, unsupported attacks, passive economies, repetitive diplomacy, ineffective research choices and similar defects where the audit finds them. Avoid oscillating between contradictory plans or issuing excessive orders every tick.

The AI should operate through the same valid action paths and information rules as the player. If difficulty uses bonuses, define and disclose them separately. Greater difficulty should also reflect improved decisions where feasible.

Use lightweight, reproducible diagnostics that explain important decisions. Compare fixed-seed campaigns before and after changes, across maps and difficulties. Track varied outcomes, economic failures, inactivity, war behavior and victory paths. Do not force every faction to have equal win rates, infer balance from a handful of runs, or claim the AI is sophisticated merely because it never crashes.

## 10. Three new playable maps

Retain existing campaigns and their save mappings. Add these distinct selectable campaigns:

1. **Huge Earth world map.** Recognizable continents and major geographical constraints, meaningful ocean travel, multiple strategic theaters and a substantial scale increase over the current largest campaign.
2. **Large Europe map.** Recognizable European geography with more regional detail and strategic density than a cropped low-detail world map.
3. **Large original fictional world.** Authored geography and balanced scenario structure with its own strategic character, not a reskinned arrangement of the existing provinces.

Establish target province and faction counts after profiling the current engine. Document each target, achieved count and comparison with existing maps. Preserve the requested sense of scale; unnecessary subdivision is not a substitute for meaningful geography. Resolve performance through measured improvements and suitable levels of detail rather than silently replacing the huge map with a small one.

For Earth and Europe, choose a coherent scenario framing that fits the game's time period and systems. State whether a campaign uses historical or fictional political setups. Do not present invented borders, capabilities or faction assignments as historical facts. Obtain source geography from appropriate licensed data and include required attribution. Use suitable identities rather than assigning generic fictional flags to real countries indiscriminately.

Validate coastlines, province polygons, adjacency, land/sea connections, island access, chokepoints, capitals, ownership, starting forces, resources, supply and victory conditions. Ensure visible geography agrees with movement rules. Make campaign setup explain scale, scenario identity and expected play style.

## 11. Refine map making

Inspect the existing editor, importer or generator and improve it into a dependable authoring workflow. Preserve compatibility where practical. If it is currently only a placeholder, complete the basic workflow required for the requested custom-map capability.

Improve the existing tools for geography, province layout, terrain, ownership, adjacency and starting scenario data as applicable. Make edits easy to understand and undo. Keep map definitions separate from a campaign's transient save state.

Custom maps must be importable, exportable, selectable and playable with the same simulation as built-in maps. Round-trip an actual edited map through export, import, setup, play and save reload. Reject malformed or unsafe input with precise messages.

Validation should identify the location and cause of disconnected provinces, invalid crossings, missing capitals, unusable starts, broken identifiers and other relevant defects. Give users a clear path to fix them. An attractive paint surface without playable map validation does not meet this requirement.

Use a documented shared map/scenario format for the new built-in maps and custom maps. Avoid maintaining unrelated special-case renderers or simulations for each campaign.

## 12. Map presentation and overlays

Improve shorelines, terrain composition, borders, labels, capitals, counters, routes, occupation and contested areas. Keep political identity, unit positions and strategic constraints readable at every scale.

- **World view:** major geography, realm names, important borders, capitals and essential fronts.
- **Regional view:** collision-checked province names, terrain, units and strategic routes.
- **Local view:** richer landmarks and useful finer detail supported by the simulation.

Use one coherent collision and priority approach for labels and markers. Keep full names available in an inspector when a label must be suppressed. Avoid fixed-size imagery covering provinces or ownership boundaries.

Refine existing map modes and presentation controls. Make political/occupation, terrain/movement, supply/infrastructure, economic, diplomatic and military information available where the underlying data exists. Each mode needs a truthful legend. Do not create fictional statistics or expose information the player should not know.

Distinguish campaign selection from map-mode overlays. Keep common controls visible and advanced detail settings accessible without cluttering the main play surface.

## 13. Performance, bugs and saves

Profile before and after using the same declared conditions. Test the largest world campaign as well as the existing smaller maps. Measure simulation tick time, map interaction/frame work, startup, memory and save/load. Record percentiles or worst cases where meaningful; avoid averages that hide freezes.

Keep repeated rendering work bounded: cull off-screen objects, cache static geometry and artwork, use zoom-dependent detail, load rich images when useful, and avoid recreating paths, labels or textures every frame. Optimize AI scheduling and expensive queries with evidence. Use a worker or architectural change if measurements justify it.

Maintain a usable browser experience on ordinary laptops and Chromebooks, and functional mobile/touch layouts. Keep fonts and essential assets locally available. Verify the production deployment base path and avoid runtime dependencies that break static hosting.

Preserve existing saves, original map identifiers and deterministic behavior where the project relies on it. If a schema change requires migration, provide a versioned migration, a backup path, explicit unsupported-version errors and real old-save tests. Never silently discard a save or interpret it under the wrong map.

Fix discovered simulation, interaction and deployment bugs. Changes should be reviewable and supported by meaningful checks, not hidden among aesthetic edits.

## 14. Implementation and verification

Build one cohesive release in one working pass. Internally establish the visual system and map/HUD first, integrate the system refinements and new maps, then repeatedly review actual gameplay against this brief. Keep logical commits and a PR as you work. Do not hand off an unfinished sequence of separate mini-updates.

Verify at least:

- The project's build, type checks and relevant tests.
- Trade shortages, commitments, delivery/accounting and economic recovery.
- Orders, terrain/supply effects, representative battles and peace outcomes.
- Diplomatic decisions and research/focus prerequisites/effects where implemented.
- AI behavior across reproducible scenarios and several declared seeds/difficulties.
- All campaign starts, important island/crossing paths and custom-map round trips.
- Old and new save/load paths, reload persistence and invalid-import handling.
- Every screen in the coverage inventory, including Chronicle, Help, utility dialogs and nested inspectors; representative normal, crowded, empty, disabled and error states.
- Desktop and narrow layouts, keyboard focus, touch access, resize, scrolling, covered-map input isolation and several zoom tiers.
- Actual deployment subpaths, asset/font loading and absence of browser errors.
- Performance under a late-game or comparable stress state on the huge Earth map.

Use focused simulation/integration tests for consequential rule changes and real browser interactions for interface behavior. Inspect screenshots with representative content, long names, shortages, crowded fronts and dialogs. A neat initial view alone is insufficient. Run meaningful human-style play sequences as well as AI-only batches, and state what real-device or browser testing was unavailable.

## 15. Completion and handoff

The update is complete when:

- Every surface in the screen inventory has a coherent, visibly transformed art direction and verified interaction states; no untouched generic menu shell remains. Each screen uses a composition suited to its actual task.
- Existing systems contain stronger strategic choices and clearer consequences, with documented examples of how they improved.
- The three requested new maps are playable, distinct and validated.
- Custom-map authoring/import/export leads to a working campaign.
- Save compatibility, production build and relevant checks pass.
- Measured performance is reported honestly and serious observed regressions are resolved.

Finish with one reviewable pull request, ready for review once the relevant checks pass. Leave it unmerged and unpublished unless separately authorized. Include a concise release summary, system-change rationale, map counts and provenance, comparable before/after game screenshots, actual test and performance results, and known limitations. Update the repository's existing documentation without inventing successful tests or complete features.

If an external dependency or unavailable capability genuinely blocks a requirement, identify the exact blocker and the remaining gap. Do not quietly omit it or label a visual placeholder as finished. Continue all independent work that remains possible.

The acceptance bar is a distinctive, polished strategy game with substantially better decisions and a credible foundation for later growth. More panels, more provinces and more numerical modifiers alone do not satisfy it.
